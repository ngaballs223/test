import discord
from discord.ext import commands
import aiohttp
import os
import logging
import asyncio
from datetime import datetime, timedelta
from typing import Optional, Dict, Any

# Set up logging for debugging authorization issues
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Bot configuration
DISCORD_BOT_TOKEN = os.getenv('DISCORD_BOT_TOKEN')
DISCORD_OWNER_ID = int(os.getenv('DISCORD_OWNER_ID', '0'))

if not DISCORD_BOT_TOKEN:
    raise ValueError("DISCORD_BOT_TOKEN environment variable is required")

if DISCORD_OWNER_ID == 0:
    logger.warning("DISCORD_OWNER_ID not set - authorization features will not work")

# Bot intents for global access (DMs, GCs, servers)
intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True
intents.guild_messages = True
intents.dm_messages = True

# Hardcoded authorized users list
AUTHORIZED_USERS = {
    931954020766081054,   # Owner ID
    1231303599687073863,
    1231259717574201374,
    669054801660870668,
    486552200143699974,
    998422652635058257,
    776214689255915520
}

# In-memory storage for tracked players and their previous states
tracked_players = {}  # {user_id: [player_names]}
player_states = {}    # {player_name: {last_stats, last_check_time, tracking_channels, active_match_msg, last_match_state}}

# Initialize bot with DM support
bot = commands.Bot(command_prefix='/', intents=intents)

# Configure bot to work in DMs
@bot.event
async def on_command_error(ctx, error):
    """Handle command errors, including DM usage"""
    if isinstance(error, commands.NoPrivateMessage):
        # Allow commands in DMs by ignoring this error
        pass
    else:
        logger.error(f"Command error: {error}")

def is_owner(user_id: int) -> bool:
    """Check if user is the bot owner"""
    return user_id == DISCORD_OWNER_ID

def is_authorized(user_id: int) -> bool:
    """Check if user is in the authorized users list"""
    is_authorized_user = user_id in AUTHORIZED_USERS
    
    logger.info(f"Authorization check: User ID {user_id}")
    logger.info(f"Is authorized: {is_authorized_user}")
    
    return is_authorized_user

async def get_player_stats(player_name: str) -> Optional[Dict[str, Any]]:
    """Fetch player statistics from Critical Ops API"""
    try:
        # Use the correct working API endpoint from the original code
        url = f"https://api-cops.criticalforce.fi/api/public/profile?usernames={player_name}"
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    # API returns array, get first player
                    if data and len(data) > 0:
                        return data[0]
                    else:
                        logger.error(f"No player data found for {player_name}")
                        return None
                else:
                    logger.error(f"API request failed with status {response.status}")
                    return None
    except Exception as e:
        logger.error(f"Error fetching stats for {player_name}: {e}")
        return None

def format_ban_status(ban_data: Optional[Dict[str, Any]]) -> str:
    """Format ban status for display"""
    if not ban_data:
        return "N/A"
    
    # Ban reason lookup table
    ban_reasons = {
        1: "Cheating",
        2: "Abusive Behavior", 
        3: "Exploiting",
        4: "Team Killing",
        5: "Inappropriate Name",
        6: "Spam",
        7: "Other"
    }
    
    ban_type = ban_data.get('Type', ban_data.get('type', 0))
    reason_id = ban_data.get('Reason', ban_data.get('reason', 0))
    seconds_left = ban_data.get('SecondsLeft', ban_data.get('expires_at', 0))
    
    ban_reason = ban_reasons.get(reason_id, "Unknown")
    
    if seconds_left and seconds_left > 0:
        return f"Temporary - {ban_reason}"
    else:
        return f"Permanent - {ban_reason}"

def detect_ranked_match_by_stats(player_name: str, current_data: Dict[str, Any]) -> tuple[bool, dict]:
    """Detect if player is in ranked match by comparing stats changes"""
    if player_name not in player_states:
        return False, {}
    
    state = player_states[player_name]
    last_stats = state.get('last_stats', {})
    
    # Get current Season 15 ranked stats
    current_stats = current_data.get('stats', {})
    current_seasonal = current_stats.get('seasonal_stats', [])
    current_s15_ranked = None
    
    for season in current_seasonal:
        if season.get('season') == 15:
            current_s15_ranked = season.get('ranked', {})
            break
    
    # Get last Season 15 ranked stats
    last_stats_data = last_stats.get('stats', {})
    last_seasonal = last_stats_data.get('seasonal_stats', [])
    last_s15_ranked = None
    
    for season in last_seasonal:
        if season.get('season') == 15:
            last_s15_ranked = season.get('ranked', {})
            break
    
    if not current_s15_ranked or not last_s15_ranked:
        return False, {}
    
    # Compare stats to detect changes
    current_kills = current_s15_ranked.get('k', 0)
    current_deaths = current_s15_ranked.get('d', 0)
    current_assists = current_s15_ranked.get('a', 0)
    
    last_kills = last_s15_ranked.get('k', 0)
    last_deaths = last_s15_ranked.get('d', 0)
    last_assists = last_s15_ranked.get('a', 0)
    
    # Check if any ranked stats increased
    kills_diff = current_kills - last_kills
    deaths_diff = current_deaths - last_deaths  
    assists_diff = current_assists - last_assists
    
    if kills_diff > 0 or deaths_diff > 0 or assists_diff > 0:
        logger.info(f"Ranked stats changed for {player_name}: K+{kills_diff}, D+{deaths_diff}, A+{assists_diff}")
        
        # Initialize match tracking if not already set
        if 'match_start_stats' not in state:
            state['match_start_stats'] = {
                'k': last_kills,
                'd': last_deaths,
                'a': last_assists
            }
            logger.info(f"Set match start stats for {player_name}: {state['match_start_stats']}")
        
        # Calculate total match KDA from start
        match_start = state['match_start_stats']
        match_kills = current_kills - match_start['k']
        match_deaths = current_deaths - match_start['d']
        match_assists = current_assists - match_start['a']
        
        return True, {
            'match_kills': max(0, match_kills),
            'match_deaths': max(0, match_deaths),
            'match_assists': max(0, match_assists)
        }
    
    return False, {}

def extract_current_match_kda(player_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Extract current match KDA if available"""
    # This would extract live match data if available from the API
    # For now, we'll return None as the API structure for live matches isn't clear
    # In a real implementation, this would parse live match data
    return None

async def send_notification_to_trackers(player_name: str, message: str, embed: discord.Embed = None):
    """Send notifications to all users tracking a specific player"""
    if player_name not in player_states:
        return
        
    state = player_states[player_name]
    
    # Send to all tracking channels
    for channel_id in state.get('tracking_channels', []):
        try:
            channel = bot.get_channel(channel_id)
            if channel and hasattr(channel, 'send'):
                if embed:
                    await channel.send(message, embed=embed)
                else:
                    await channel.send(message)
        except Exception as e:
            logger.error(f"Failed to send notification to channel {channel_id}: {e}")

async def send_ranked_status_message(player_name: str, player_data: Dict[str, Any], user_id: int = None):
    """Send initial ranked match status message"""
    if player_name not in player_states:
        logger.info(f"Player {player_name} not in player_states")
        return
        
    state = player_states[player_name]
    current_username = player_data.get('basicInfo', {}).get('name', player_name)
    
    logger.info(f"Checking ranked status for {current_username}")
    
    # Check if player is in ranked match by stat changes
    is_in_match, match_kda = detect_ranked_match_by_stats(player_name, player_data)
    
    if is_in_match:
        logger.info(f"{current_username} is in a ranked match (detected by stat changes)!")
        
        match_kills = match_kda.get('match_kills', 0)
        match_deaths = match_kda.get('match_deaths', 0) 
        match_assists = match_kda.get('match_assists', 0)
        match_kd = round(match_kills / match_deaths, 2) if match_deaths > 0 else match_kills
        
        embed = discord.Embed(
            title="⚔️ **Currently In Ranked**",
            description=f"**{current_username}** is actively playing a ranked match",
            color=discord.Color.orange()
        )
        embed.add_field(name="**Live Match KDA**", value=f"• **Kills:** {match_kills}\n• **Deaths:** {match_deaths}\n• **Assists:** {match_assists}", inline=False)
        embed.add_field(name="**K/D Ratio**", value=f"{match_kd}", inline=True)
        embed.add_field(name="**Status**", value="🔴 **Live Match**", inline=True)
        
        # Send to all tracking channels and store message for editing
        tracking_channels = state.get('tracking_channels', [])
        logger.info(f"Tracking channels for {current_username}: {tracking_channels}")
        
        for channel_id in tracking_channels:
            try:
                logger.info(f"Attempting to send ranked match message to channel {channel_id}")
                channel = bot.get_channel(channel_id)
                logger.info(f"Channel object: {channel}")
                
                if channel and hasattr(channel, 'send'):
                    logger.info(f"Sending ranked match embed with KDA: K={match_kills}, D={match_deaths}, A={match_assists}")
                    # Add user ping if user_id is provided
                    ping_text = f"<@{user_id}> 🏆 **Live Ranked Match**" if user_id else "🏆 **Live Ranked Match**"
                    msg = await channel.send(ping_text, embed=embed)
                    logger.info(f"Successfully sent message: {msg.id}")
                    
                    # Store message for editing
                    if 'active_match_messages' not in state:
                        state['active_match_messages'] = {}
                    state['active_match_messages'][channel_id] = msg
                    state['in_ranked_match'] = True
                    state['last_match_kda'] = {'k': match_kills, 'd': match_deaths, 'a': match_assists}
                    logger.info(f"Stored message for future editing in channel {channel_id}")
                else:
                    logger.warning(f"Channel {channel_id} not found or doesn't have send method")
            except Exception as e:
                logger.error(f"Failed to send ranked status to channel {channel_id}: {e}")
                import traceback
                logger.error(f"Full traceback: {traceback.format_exc()}")
    else:
        logger.info(f"{current_username} is not in a ranked match")
        
        # Send a temporary message indicating no active match (for debugging)
        for channel_id in state.get('tracking_channels', []):
            try:
                channel = bot.get_channel(channel_id)
                if channel and hasattr(channel, 'send'):
                    embed = discord.Embed(
                        title="ℹ️ **Match Status**",
                        description=f"**{current_username}** is not currently in a ranked match",
                        color=discord.Color.blue()
                    )
                    embed.add_field(name="**Status**", value="⚪ **Not in Match**", inline=True)
                    await channel.send("📊 **Match Check**", embed=embed)
                    logger.info(f"Sent 'not in match' message to channel {channel_id}")
            except Exception as e:
                logger.error(f"Failed to send match status to channel {channel_id}: {e}")

async def update_ranked_match_message(player_name: str, player_data: Dict[str, Any]):
    """Update existing ranked match message with new KDA"""
    if player_name not in player_states:
        return
        
    state = player_states[player_name]
    if not state.get('in_ranked_match') or 'active_match_messages' not in state:
        return
    
    current_username = player_data.get('basicInfo', {}).get('name', player_name)
    
    # Get current season stats
    stats = player_data.get('stats', {})
    seasonal_stats = stats.get('seasonal_stats', [])
    season_15_data = None
    
    for season in seasonal_stats:
        if season.get('season') == 15:
            season_15_data = season
            break
    
    if season_15_data:
        ranked_s15 = season_15_data.get('ranked', {})
        current_kills = ranked_s15.get('k', 0)
        current_deaths = ranked_s15.get('d', 0)
        current_assists = ranked_s15.get('a', 0)
        
        # Calculate match-specific KDA progression
        match_start = state.get('match_start_stats', {})
        if match_start:
            start_kills = match_start.get('k', 0)
            start_deaths = match_start.get('d', 0)
            start_assists = match_start.get('a', 0)
            
            match_kills = max(0, current_kills - start_kills)
            match_deaths = max(0, current_deaths - start_deaths)
            match_assists = max(0, current_assists - start_assists)
            match_kd = round(match_kills / match_deaths, 2) if match_deaths > 0 else match_kills
        else:
            # Fallback if no match start stats
            match_kills = match_deaths = match_assists = 0
            match_kd = 0.0
        
        # Check if match KDA changed
        last_kda = state.get('last_match_kda', {})
        if (match_kills != last_kda.get('k', 0) or match_deaths != last_kda.get('d', 0) or match_assists != last_kda.get('a', 0)):
            # Update the embed
            embed = discord.Embed(
                title="🕹️ **Currently In Ranked**",
                description=f"**{current_username}** is actively playing a ranked match",
                color=discord.Color.orange()
            )
            embed.add_field(name="**Live Match KDA**", value=f"• **Kills:** {match_kills}\n• **Deaths:** {match_deaths}\n• **Assists:** {match_assists}", inline=False)
            embed.add_field(name="**K/D Ratio**", value=f"{match_kd}", inline=True)
            embed.add_field(name="**Status**", value="🔴 **Live Match - Updated**", inline=True)
            
            # Edit all active match messages
            for channel_id, message in state['active_match_messages'].items():
                try:
                    await message.edit(content="🏆 **Live Ranked Match - Updated**", embed=embed)
                except Exception as e:
                    logger.error(f"Failed to edit ranked message in channel {channel_id}: {e}")
            
            # Update stored match KDA
            state['last_match_kda'] = {'k': match_kills, 'd': match_deaths, 'a': match_assists}

async def finalize_ranked_match(player_name: str, player_data: Dict[str, Any], mmr_change: int):
    """Finalize ranked match with final results"""
    if player_name not in player_states:
        return
        
    state = player_states[player_name]
    if not state.get('in_ranked_match') or 'active_match_messages' not in state:
        return
    
    current_username = player_data.get('basicInfo', {}).get('name', player_name)
    
    # Get final season stats
    stats = player_data.get('stats', {})
    seasonal_stats = stats.get('seasonal_stats', [])
    season_15_data = None
    
    for season in seasonal_stats:
        if season.get('season') == 15:
            season_15_data = season
            break
    
    if season_15_data:
        ranked_s15 = season_15_data.get('ranked', {})
        current_kills = ranked_s15.get('k', 0)
        current_deaths = ranked_s15.get('d', 0)
        current_assists = ranked_s15.get('a', 0)
        wins = ranked_s15.get('w', 0)
        losses = ranked_s15.get('l', 0)
        
        # Calculate final match KDA
        match_start = state.get('match_start_stats', {})
        if match_start:
            start_kills = match_start.get('k', 0)
            start_deaths = match_start.get('d', 0)
            start_assists = match_start.get('a', 0)
            
            final_match_kills = max(0, current_kills - start_kills)
            final_match_deaths = max(0, current_deaths - start_deaths)
            final_match_assists = max(0, current_assists - start_assists)
            match_kd = round(final_match_kills / final_match_deaths, 2) if final_match_deaths > 0 else final_match_kills
        else:
            # Fallback if no match start stats
            final_match_kills = final_match_deaths = final_match_assists = 0
            match_kd = 0.0
        
        # Get current MMR
        current_mmr = stats.get('ranked', {}).get('mmr', 0)
        
        change_symbol = "📈" if mmr_change > 0 else "📉"
        change_text = f"+{mmr_change}" if mmr_change > 0 else str(mmr_change)
        
        # Create visually appealing completion embed
        embed = discord.Embed(
            title="🏆 **Ranked Match Complete**",
            description=f"**{current_username}** has finished their ranked match",
            color=discord.Color.green() if mmr_change > 0 else discord.Color.red()
        )
        
        # Match Performance section
        performance_text = f"```\n🎯  K/D/A: {final_match_kills}/{final_match_deaths}/{final_match_assists}\n📊  Match K/D: {match_kd}\n```"
        embed.add_field(name="⚔️ **Match Performance**", value=performance_text, inline=False)
        
        # MMR & Stats section in a more organized way
        mmr_section = f"```diff\n{'+' if mmr_change > 0 else '-'} {abs(mmr_change)} MMR\n```\n🏅 **New MMR:** {current_mmr:,}"
        embed.add_field(name=f"{change_symbol} **MMR Update**", value=mmr_section, inline=True)
        
        # Season stats
        season_stats = f"```\n🏆 {wins}W / {losses}L\n📈 {round(wins/(wins+losses)*100, 1) if (wins+losses) > 0 else 0}% Win Rate\n```"
        embed.add_field(name="📊 **Season 15 Stats**", value=season_stats, inline=True)
        
        # Edit all active match messages with final results
        for channel_id, message in state['active_match_messages'].items():
            try:
                await message.edit(content=f"{change_symbol} **Match Completed**", embed=embed)
            except Exception as e:
                logger.error(f"Failed to edit final ranked message in channel {channel_id}: {e}")
        
        # Clean up match tracking
        state['in_ranked_match'] = False
        state['active_match_messages'] = {}
        state['last_match_kda'] = {}
        state['match_start_stats'] = {}

async def check_player_updates():
    """Background task to monitor tracked players for changes"""
    while True:
        try:
            for player_name, state in list(player_states.items()):
                # Use different intervals for players in ranked matches
                if state.get('in_ranked_match'):
                    # Check every 1 minute for active matches
                    if datetime.utcnow() - state['last_check_time'] < timedelta(minutes=1):
                        continue
                else:
                    # Only check players that have been checked more than 30 seconds ago
                    if datetime.utcnow() - state['last_check_time'] < timedelta(seconds=30):
                        continue
                    
                # Fetch current player data
                current_data = await get_player_stats(state['last_username'])
                if not current_data:
                    continue
                    
                # Update last check time
                state['last_check_time'] = datetime.utcnow()
                
                # Check for username changes
                current_username = current_data.get('basicInfo', {}).get('name', state['last_username'])
                if current_username != state['last_username']:
                    embed = discord.Embed(
                        title="📝 Username Changed",
                        description=f"**{state['last_username']}** changed their name to **{current_username}**",
                        color=0xFFAA00
                    )
                    await send_notification_to_trackers(player_name, f"🔄 **Username Update**", embed)
                    
                    # Update stored username
                    state['last_username'] = current_username
                
                # Check for ban status changes
                current_ban = current_data.get('ban')
                last_ban = state.get('last_ban_status')
                
                if current_ban != last_ban:
                    if current_ban:  # Player got banned
                        ban_reason = current_ban.get('reason', 'Unknown')
                        ban_type = current_ban.get('type', 'Unknown')
                        ban_expires = current_ban.get('expires_at', 'Permanent')
                        
                        if ban_expires and ban_expires != 'Permanent':
                            ban_duration = f"Until {ban_expires}"
                        else:
                            ban_duration = "Permanent"
                            
                        embed = discord.Embed(
                            title="⚠️ Player Banned",
                            description=f"**{current_username}** has been banned from Critical Ops",
                            color=0xFF4444
                        )
                        embed.add_field(name="Reason", value=ban_reason, inline=True)
                        embed.add_field(name="Type", value=ban_type, inline=True)
                        embed.add_field(name="Duration", value=ban_duration, inline=True)
                        
                        await send_notification_to_trackers(player_name, f"🚫 **Ban Alert**", embed)
                    else:  # Player got unbanned
                        embed = discord.Embed(
                            title="✅ Player Unbanned",
                            description=f"**{current_username}** is no longer banned",
                            color=0x00FF00
                        )
                        await send_notification_to_trackers(player_name, f"🎉 **Unban Alert**", embed)
                
                # Check for MMR/ranked changes and match status
                current_stats = current_data.get('stats', {})
                current_ranked = current_stats.get('ranked', {})
                current_mmr = current_ranked.get('mmr', 0)
                
                last_mmr = state.get('last_mmr')
                
                # Check if player stats changed (indicating ranked match activity)
                was_in_match = state.get('in_ranked_match', False)
                is_in_match, match_kda = detect_ranked_match_by_stats(player_name, current_data)
                
                if is_in_match and not was_in_match:
                    # Player just entered a ranked match (stats changed)
                    await send_ranked_status_message(player_name, current_data)
                elif is_in_match and was_in_match:
                    # Player is still in ranked match, update KDA
                    await update_ranked_match_message(player_name, current_data)
                elif not is_in_match and was_in_match:
                    # Player stats stopped changing (match ended)
                    if last_mmr and current_mmr and current_mmr != last_mmr:
                        mmr_change = current_mmr - last_mmr
                        await finalize_ranked_match(player_name, current_data, mmr_change)
                    else:
                        # Match ended but no MMR change detected, still finalize
                        await finalize_ranked_match(player_name, current_data, 0)
                
                # Check for MMR changes (for non-live match notifications)
                if not is_in_match and last_mmr and current_mmr and current_mmr != last_mmr:
                    mmr_change = current_mmr - last_mmr
                    change_symbol = "📈" if mmr_change > 0 else "📉"
                    change_text = f"+{mmr_change}" if mmr_change > 0 else str(mmr_change)
                    
                    # Get current season ranked stats
                    seasonal_stats = current_stats.get('seasonal_stats', [])
                    season_15_data = None
                    for season in seasonal_stats:
                        if season.get('season') == 15:
                            season_15_data = season
                            break
                    
                    if season_15_data:
                        ranked_s15 = season_15_data.get('ranked', {})
                        kills = ranked_s15.get('k', 0)
                        deaths = ranked_s15.get('d', 0) 
                        assists = ranked_s15.get('a', 0)
                        wins = ranked_s15.get('w', 0)
                        losses = ranked_s15.get('l', 0)
                        kd_ratio = round(kills / deaths, 2) if deaths > 0 else kills
                        
                        embed = discord.Embed(
                            title=f"{change_symbol} Ranked Match Completed",
                            description=f"**{current_username}** finished a ranked match",
                            color=0x00FFFF
                        )
                        embed.add_field(name="MMR Change", value=f"{change_text} MMR", inline=True)
                        embed.add_field(name="New MMR", value=f"{current_mmr:,}", inline=True)
                        embed.add_field(name="Season 15 Stats", value=f"**K/D:** {kd_ratio}\n**W/L:** {wins}/{losses}", inline=True)
                        
                        await send_notification_to_trackers(player_name, f"🏆 **Ranked Update**", embed)
                
                # Update stored states
                state['last_stats'] = current_data
                state['last_ban_status'] = current_ban
                state['last_mmr'] = current_mmr if current_mmr > 0 else None
                
        except Exception as e:
            logger.error(f"Error in background monitoring: {e}")
        
        # Wait 30 seconds before next check (or 1 minute for active matches)
        await asyncio.sleep(30)

@bot.event
async def on_ready():
    """Bot startup event"""
    logger.info(f'{bot.user} has connected to Discord!')
    logger.info(f'Owner ID: {DISCORD_OWNER_ID}')
    
    try:
        # Sync application commands
        synced = await bot.tree.sync()
        logger.info(f"Synced {len(synced)} commands")
    except Exception as e:
        logger.error(f"Failed to sync commands: {e}")
    
    # Start background monitoring task
    bot.loop.create_task(check_player_updates())

@bot.tree.command(name="snipe", description="Track a Critical Ops player")
@discord.app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
async def snipe_player(interaction: discord.Interaction, player_name: str):
    """Track a Critical Ops player with enhanced features - Available to authorized users"""
    # Check authorization
    if interaction.user.id not in AUTHORIZED_USERS:
        await interaction.response.send_message("You are not authorized to use this command.", ephemeral=True)
        return
    
    await interaction.response.defer()
    
    try:
        # Fetch player data
        data = await get_player_stats(player_name)
        if not data:
            await interaction.followup.send(f"❌ Player **{player_name}** not found.")
            return
        
        # Extract player information
        basic_info = data.get('basicInfo', {})
        username = basic_info.get('name', player_name)
        level = basic_info.get('playerLevel', {}).get('level', 0)
        
        # Ban status with enhanced formatting
        ban_data = data.get('ban')
        ban_status = format_ban_status(ban_data)
        
        # Get stats
        stats = data.get('stats', {})
        player_info = data
        
        # Get seasonal stats 
        seasonal_stats = stats.get('seasonal_stats', [])
        
        # Get current MMR from ranked stats
        ranked_api_stats = stats.get('ranked', {})
        current_mmr = ranked_api_stats.get('mmr', 0)
        
        # Get Season 15 ranked stats specifically
        season_15_ranked = {'k': 0, 'd': 0, 'a': 0, 'w': 0, 'l': 0}
        for season in seasonal_stats:
            if season.get('season') == 15:
                season_15_ranked = season.get('ranked', {})
                break
        
        s15_ranked_kills = season_15_ranked.get('k', 0)
        s15_ranked_deaths = season_15_ranked.get('d', 0)
        s15_ranked_assists = season_15_ranked.get('a', 0)
        s15_ranked_wins = season_15_ranked.get('w', 0)
        s15_ranked_losses = season_15_ranked.get('l', 0)
        
        # Calculate total casual + custom stats from all seasons
        total_casual_kills = total_casual_deaths = total_casual_assists = 0
        for season in seasonal_stats:
            casual_season = season.get('casual', {})
            custom_season = season.get('custom', {})
            total_casual_kills += casual_season.get('k', 0) + custom_season.get('k', 0)
            total_casual_deaths += casual_season.get('d', 0) + custom_season.get('d', 0)
            total_casual_assists += casual_season.get('a', 0) + custom_season.get('a', 0)
        
        # Calculate K/D ratios
        s15_ranked_kd = round(s15_ranked_kills / s15_ranked_deaths, 2) if s15_ranked_deaths > 0 else s15_ranked_kills
        casual_kd = round(total_casual_kills / total_casual_deaths, 2) if total_casual_deaths > 0 else total_casual_kills
        
        # Get account ID and clan info  
        account_id = basic_info.get('userID', 'N/A')
        clan_info = player_info.get('clan', {}).get('basicInfo', {})
        clan_tag = clan_info.get('tag', 'N/A')
        clan_name = clan_info.get('name', '')
        
        # Format clan display as [Tag] - Name
        if clan_tag != 'N/A' and clan_name:
            clan_display = f"[{clan_tag}] - {clan_name}"
        elif clan_tag != 'N/A':
            clan_display = clan_tag
        else:
            clan_display = 'N/A'
        
        # Create enhanced embed with proper formatting
        embed = discord.Embed(
            title=f"🦧 **{username} — Season 15**",
            color=discord.Color.teal()  # Cyan/teal border
        )
        
        # Player info section
        player_info_text = f"🆔 **Account ID:** {account_id}\n🏷️ **Clan:** {clan_display}\n📋 **Ban Status:** {ban_status}"
        embed.add_field(name="", value=player_info_text, inline=False)
        
        # ELO and Level section
        elo_level_text = f"🏅 **ELO:** {current_mmr:,}\n📊 **Level:** {level}"
        embed.add_field(name="", value=elo_level_text, inline=False)
        
        # Casual Stats section (total casual + custom stats)
        casual_stats_text = f"• **Kills:** {total_casual_kills:,}\n• **Deaths:** {total_casual_deaths:,}\n• **Assists:** {total_casual_assists:,}\n• **K/D Ratio:** {casual_kd}"
        embed.add_field(name="⚔️ **Casual Stats**", value=casual_stats_text, inline=False)
        
        # Ranked Stats section (Season 15 only)  
        ranked_stats_text = f"• **Kills:** {s15_ranked_kills:,}\n• **Deaths:** {s15_ranked_deaths:,}\n• **Assists:** {s15_ranked_assists:,}\n• **Wins:** {s15_ranked_wins}\n• **Losses:** {s15_ranked_losses}\n• **K/D Ratio:** {s15_ranked_kd}"
        embed.add_field(name="🏆 **Ranked Stats (S15)**", value=ranked_stats_text, inline=False)
        
        # Add ban details if player is banned
        if ban_data:
            ban_reasons = {
                1: "Cheating",
                2: "Abusive Behavior", 
                3: "Exploiting",
                4: "Team Killing",
                5: "Inappropriate Name",
                6: "Spam",
                7: "Other"
            }
            reason_id = ban_data.get('Reason', ban_data.get('reason', 0))
            ban_reason = ban_reasons.get(reason_id, "Unknown")
            embed.add_field(name="🚫 **Banned**", value=f"**Reason:** {ban_reason}", inline=False)
        
        await interaction.followup.send(embed=embed)
        
        # Track this player for the user
        user_id = interaction.user.id
        if user_id not in tracked_players:
            tracked_players[user_id] = []
        
        if player_name not in tracked_players[user_id]:
            tracked_players[user_id].append(player_name)
        
        # Initialize player state for monitoring
        if player_name not in player_states:
            player_states[player_name] = {
                'last_stats': data,
                'last_check_time': datetime.utcnow(),
                'tracking_channels': [],
                'last_username': username,
                'last_ban_status': ban_data,
                'last_mmr': current_mmr if current_mmr > 0 else None,
                'in_ranked_match': False,
                'active_match_messages': {},
                'last_match_kda': {}
            }
        
        # Add this channel to tracking list
        if interaction.channel and interaction.channel.id not in player_states[player_name]['tracking_channels']:
            player_states[player_name]['tracking_channels'].append(interaction.channel.id)
        
        # Send tracking confirmation
        tracking_embed = discord.Embed(
            title="🟢 Now Tracking",
            description=f"**{username}** is now being monitored for updates",
            color=0x00FF00
        )
        tracking_embed.add_field(
            name="Monitoring Features:",
            value="• 🏆 Ranked match notifications (KDA, MMR changes)\n• ⚠️ Ban status alerts (reason, duration)\n• 📝 Username change notifications\n• 📊 Real-time stat updates",
            inline=False
        )
        tracking_embed.add_field(
            name="Stop Tracking",
            value=f"Use `/unsnipe {username}` to stop tracking.",
            inline=False
        )
        
        await interaction.followup.send(embed=tracking_embed)
        
        # Check if player is currently in a ranked match and send status
        await send_ranked_status_message(player_name, data, interaction.user.id)
        
    except Exception as e:
        logger.error(f"Error in snipe command: {e}")
        await interaction.followup.send("❌ An error occurred while fetching player data.")

@bot.tree.command(name="unsnipe", description="Stop tracking a Critical Ops player")
@discord.app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
async def unsnipe_player(interaction: discord.Interaction, player_name: str):
    """Stop tracking a Critical Ops player - Available to authorized users"""
    # Check authorization
    if interaction.user.id not in AUTHORIZED_USERS:
        await interaction.response.send_message("You are not authorized to use this command.", ephemeral=True)
        return
    
    user_id = interaction.user.id
    
    # Remove player from user's tracking list
    if user_id in tracked_players and player_name in tracked_players[user_id]:
        tracked_players[user_id].remove(player_name)
        
        # Remove channel from player's tracking channels
        if player_name in player_states and interaction.channel:
            if interaction.channel.id in player_states[player_name]['tracking_channels']:
                player_states[player_name]['tracking_channels'].remove(interaction.channel.id)
            
            # If no one is tracking this player anymore, remove from states
            if not player_states[player_name]['tracking_channels']:
                del player_states[player_name]
        
        embed = discord.Embed(
            title="🔴 Stopped Tracking",
            description=f"No longer monitoring **{player_name}**",
            color=0xFF4444
        )
        await interaction.response.send_message(embed=embed)
    else:
        await interaction.response.send_message(f"❌ You are not currently tracking **{player_name}**.")

@bot.tree.command(name="list", description="Show your tracked players")
@discord.app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
async def list_tracked_players(interaction: discord.Interaction):
    """List all players you're currently tracking"""
    if interaction.user.id not in AUTHORIZED_USERS:
        await interaction.response.send_message("You are not authorized to use this command.", ephemeral=True)
        return
    
    user_id = interaction.user.id
    
    if user_id not in tracked_players or not tracked_players[user_id]:
        embed = discord.Embed(
            title="📋 Your Tracked Players",
            description="You are not currently tracking any players.",
            color=0x888888
        )
        embed.add_field(name="Start Tracking", value="Use `/snipe [player_name]` to start tracking a player.", inline=False)
        await interaction.response.send_message(embed=embed)
        return
    
    players_list = "\n".join([f"• **{player}**" for player in tracked_players[user_id]])
    
    embed = discord.Embed(
        title="📋 Your Tracked Players",
        description=players_list,
        color=0x00FFFF
    )
    embed.add_field(name="Stop Tracking", value="Use `/unsnipe [player_name]` to stop tracking a player.", inline=False)
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="authorize", description="Authorize a user to use bot commands (Owner only)")
@discord.app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
async def authorize_user(interaction: discord.Interaction, user: discord.User):
    """Authorize a user to use bot commands - Owner only"""
    if not is_owner(interaction.user.id):
        await interaction.response.send_message("❌ Only the bot owner can use this command.", ephemeral=True)
        return
    
    if user.id in AUTHORIZED_USERS:
        await interaction.response.send_message(f"✅ **{user.name}** is already authorized.", ephemeral=True)
        return
    
    AUTHORIZED_USERS.add(user.id)
    
    embed = discord.Embed(
        title="✅ User Authorized",
        description=f"**{user.name}** ({user.id}) can now use bot commands.",
        color=0x00FF00
    )
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="deauthorize", description="Remove user authorization (Owner only)")
@discord.app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
async def deauthorize_user(interaction: discord.Interaction, user: discord.User):
    """Remove user authorization - Owner only"""
    if not is_owner(interaction.user.id):
        await interaction.response.send_message("❌ Only the bot owner can use this command.", ephemeral=True)
        return
    
    if user.id == DISCORD_OWNER_ID:
        await interaction.response.send_message("❌ Cannot deauthorize the bot owner.", ephemeral=True)
        return
    
    if user.id not in AUTHORIZED_USERS:
        await interaction.response.send_message(f"❌ **{user.name}** is not currently authorized.", ephemeral=True)
        return
    
    AUTHORIZED_USERS.remove(user.id)
    
    embed = discord.Embed(
        title="🔴 User Deauthorized",
        description=f"**{user.name}** ({user.id}) can no longer use bot commands.",
        color=0xFF4444
    )
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="userlist", description="List all authorized users (Owner only)")
@discord.app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
async def list_authorized_users(interaction: discord.Interaction):
    """List all authorized users - Owner only"""
    if not is_owner(interaction.user.id):
        await interaction.response.send_message("❌ Only the bot owner can use this command.", ephemeral=True)
        return
    
    if not AUTHORIZED_USERS:
        embed = discord.Embed(
            title="👥 Authorized Users",
            description="No users are currently authorized.",
            color=0x888888
        )
        await interaction.response.send_message(embed=embed)
        return
    
    user_list = []
    for user_id in AUTHORIZED_USERS:
        try:
            user = await bot.fetch_user(user_id)
            status = "👑 Owner" if user_id == DISCORD_OWNER_ID else "✅ Authorized"
            user_list.append(f"• **{user.name}** ({user_id}) - {status}")
        except:
            user_list.append(f"• **Unknown User** ({user_id}) - ✅ Authorized")
    
    embed = discord.Embed(
        title="👥 Authorized Users",
        description="\n".join(user_list),
        color=0x00FFFF
    )
    await interaction.response.send_message(embed=embed)

if __name__ == "__main__":
    # Run the bot
    bot.run(DISCORD_BOT_TOKEN)
