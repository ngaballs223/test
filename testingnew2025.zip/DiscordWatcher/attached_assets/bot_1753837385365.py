import discord
from discord.ext import commands
import aiohttp
import asyncio
import logging
import os
from datetime import datetime, timedelta
from typing import Dict, Any, Optional

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Environment variables
DISCORD_BOT_TOKEN = os.getenv("DISCORD_BOT_TOKEN")
DISCORD_OWNER_ID = int(os.getenv("DISCORD_OWNER_ID", "0"))

if not DISCORD_BOT_TOKEN:
    logger.error("DISCORD_BOT_TOKEN environment variable is required!")
    exit(1)

# Hardcoded authorized user IDs (modify this list as needed)
AUTHORIZED_USERS = {
    DISCORD_OWNER_ID,  # Bot owner is always authorized
    931954020766081054,  # ididntwannachange
    1231303599687073863,
    1231259717574201374,
    669054801660870668,
    486552200143699974,
    998422652635058257,
    776214689255915520
}

# Remove 0 from authorized users if no owner ID was set
if DISCORD_OWNER_ID == 0:
    AUTHORIZED_USERS.discard(0)

# Bot configuration
intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True
intents.dm_messages = True

bot = commands.Bot(command_prefix='!', intents=intents)

# Global storage for tracked players and their states
tracked_players = {}  # {user_id: [player_names]}
player_states = {}    # {player_name: {last_stats, last_check_time, tracking_channels, etc.}}

def is_owner(user_id: int) -> bool:
    """Check if user is the bot owner"""
    return user_id == DISCORD_OWNER_ID and DISCORD_OWNER_ID != 0

def format_ban_status(ban_data: Optional[Dict[str, Any]]) -> str:
    """Format ban status for display"""
    if not ban_data:
        return "N/A"
    
    ban_type = ban_data.get('type', ban_data.get('Type', 'Unknown'))
    if ban_type == 'Temporary':
        expires = ban_data.get('expires_at', ban_data.get('ExpiresAt', 'Unknown'))
        return f"Temporary (expires: {expires})"
    elif ban_type == 'Permanent':
        return "Permanent"
    else:
        return ban_type

async def get_player_stats(player_name: str) -> Optional[Dict[str, Any]]:
    """Fetch player statistics from Critical Ops API"""
    try:
        # Use the correct working API endpoint from the original code
        url = f"https://api-cops.criticalforce.fi/api/public/profile?usernames={player_name}"
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    # API returns array, get first player
                    if data and len(data) > 0:
                        return data[0]
                    else:
                        logger.error(f"No player data found for {player_name}")
                        return None
                else:
                    logger.error(f"API request failed with status {response.status}")
                    return None
    except Exception as e:
        logger.error(f"Error fetching stats for {player_name}: {e}")
        return None

async def send_notification_to_trackers(player_name: str, content: str, embed: discord.Embed):
    """Send notification to all channels tracking this player"""
    if player_name not in player_states:
        return
    
    channels = player_states[player_name]['tracking_channels']
    for channel_id in channels.copy():  # Use copy to avoid modification during iteration
        try:
            channel = bot.get_channel(channel_id)
            if channel:
                await channel.send(content=content, embed=embed)
            else:
                # Channel no longer exists, remove it
                channels.remove(channel_id)
        except Exception as e:
            logger.error(f"Failed to send notification to channel {channel_id}: {e}")
            # Remove problematic channel
            if channel_id in channels:
                channels.remove(channel_id)

def is_player_in_ranked_match(player_data: Dict[str, Any]) -> bool:
    """Check if player is currently in a ranked match based on Season 15 stats changes"""
    if not player_data:
        return False
    
    # Get current Season 15 ranked stats
    stats = player_data.get('stats', {})
    seasonal_stats = stats.get('seasonal_stats', [])
    
    current_s15_data = None
    for season in seasonal_stats:
        if season.get('season') == 15:
            current_s15_data = season
            break
    
    if not current_s15_data:
        return False
    
    current_ranked = current_s15_data.get('ranked', {})
    current_kills = current_ranked.get('k', 0)
    current_deaths = current_ranked.get('d', 0)
    current_assists = current_ranked.get('a', 0)
    
    # Get player name to check stored state
    player_name = player_data.get('basicInfo', {}).get('name', '')
    if not player_name or player_name not in player_states:
        return False
    
    state = player_states[player_name]
    last_stats = state.get('last_stats', {})
    
    if not last_stats:
        return False
    
    # Get last Season 15 stats
    last_stats_data = last_stats.get('stats', {})
    last_seasonal = last_stats_data.get('seasonal_stats', [])
    
    last_s15_data = None
    for season in last_seasonal:
        if season.get('season') == 15:
            last_s15_data = season
            break
    
    if not last_s15_data:
        return False
    
    last_ranked = last_s15_data.get('ranked', {})
    last_kills = last_ranked.get('k', 0)
    last_deaths = last_ranked.get('d', 0)
    last_assists = last_ranked.get('a', 0)
    
    # Player is in match if any Season 15 ranked stat increased
    return (current_kills > last_kills or 
            current_deaths > last_deaths or 
            current_assists > last_assists)

async def send_new_match_cycle(player_name: str, player_data: Dict[str, Any]):
    """Send full message cycle (1, 2, 3) when player enters a new ranked match"""
    if player_name not in player_states:
        return
    
    state = player_states[player_name]
    current_username = player_data.get('basicInfo', {}).get('name', player_name)
    
    # Extract all player info for message 1 (player stats with pink embed)
    basic_info = player_data.get('basicInfo', {})
    level_data = basic_info.get('playerLevel', 'N/A')
    if isinstance(level_data, dict):
        level = level_data.get('level', 'N/A')
    else:
        level = level_data
    
    # Get ban status
    ban_data = player_data.get('ban')
    ban_status = format_ban_status(ban_data)
    
    # Extract stats
    stats = player_data.get('stats', {})
    seasonal_stats = stats.get('seasonal_stats', [])
    
    # Calculate total casual stats
    total_kills = total_deaths = total_assists = 0
    for season in seasonal_stats:
        casual_data = season.get('casual', {})
        total_kills += casual_data.get('k', 0)
        total_deaths += casual_data.get('d', 0) 
        total_assists += casual_data.get('a', 0)
    
    total_kd = round(total_kills / total_deaths, 2) if total_deaths > 0 else total_kills
    
    # Current ranked stats
    ranked_stats = stats.get('ranked', {})
    current_mmr = ranked_stats.get('mmr', 0)
    
    # Season 15 ranked stats
    season_15_data = None
    for season in seasonal_stats:
        if season.get('season') == 15:
            season_15_data = season
            break
    
    if season_15_data:
        ranked_s15 = season_15_data.get('ranked', {})
        s15_kills = ranked_s15.get('k', 0)
        s15_deaths = ranked_s15.get('d', 0)
        s15_assists = ranked_s15.get('a', 0)
        s15_wins = ranked_s15.get('w', 0)
        s15_losses = ranked_s15.get('l', 0)
        s15_kd = round(s15_kills / s15_deaths, 2) if s15_deaths > 0 else s15_kills
    else:
        s15_kills = s15_deaths = s15_assists = s15_wins = s15_losses = 0
        s15_kd = 0.0
    
    # Get account ID and clan info  
    account_id = basic_info.get('userID', 'N/A')
    clan_info = player_data.get('clan', {}).get('basicInfo', {})
    clan_tag = clan_info.get('tag', 'N/A')
    clan_name = clan_info.get('name', '')
    
    # Format clan display
    if clan_tag != 'N/A' and clan_name:
        clan_display = f"[{clan_tag}] - {clan_name}"
    elif clan_tag != 'N/A':
        clan_display = clan_tag
    else:
        clan_display = 'N/A'
    
    # MESSAGE 1: Player stats with pink embed
    stats_embed = discord.Embed(
        title=f"🦧 **{current_username} — Season 15**",
        color=discord.Color.magenta()
    )
    
    player_info_text = f"🆔 **Account ID:** {account_id}\n🏷️ **Clan:** {clan_display}\n📋 **Ban Status:** {ban_status}"
    stats_embed.add_field(name="", value=player_info_text, inline=False)
    
    elo_level_text = f"🏅 **ELO:** {current_mmr:,}\n📊 **Level:** {level}"
    stats_embed.add_field(name="", value=elo_level_text, inline=False)
    
    casual_stats_text = f"• **Kills:** {total_kills:,}\n• **Deaths:** {total_deaths:,}\n• **Assists:** {total_assists:,}\n• **K/D Ratio:** {total_kd}"
    stats_embed.add_field(name="⚔️ **Casual Stats**", value=casual_stats_text, inline=False)
    
    ranked_stats_text = f"• **Kills:** {s15_kills:,}\n• **Deaths:** {s15_deaths:,}\n• **Assists:** {s15_assists:,}\n• **Wins:** {s15_wins}\n• **Losses:** {s15_losses}\n• **K/D Ratio:** {s15_kd}"
    stats_embed.add_field(name="🏆 **Ranked Stats (S15)**", value=ranked_stats_text, inline=False)
    
    # MESSAGE 2: Tracking confirmation
    tracking_embed = discord.Embed(
        title="🟢 Now Tracking",
        description=f"**{current_username}** is now being monitored for updates",
        color=0x00FF00
    )
    tracking_embed.add_field(
        name="Monitoring Features:",
        value="• 🏆 Ranked match notifications (KDA, MMR changes)\n• ⚠️ Ban status alerts (reason, duration)\n• 📝 Username change notifications\n• 📊 Real-time stat updates",
        inline=False
    )
    tracking_embed.add_field(
        name="Stop Tracking",
        value=f"Use `/unsnipe {current_username}` to stop tracking.",
        inline=False
    )
    
    # Send messages 1 and 2 to all tracking channels
    channels = state['tracking_channels']
    for channel_id in channels:
        try:
            channel = bot.get_channel(channel_id)
            if channel:
                await channel.send(embed=stats_embed)
                await channel.send(embed=tracking_embed)
        except Exception as e:
            logger.error(f"Failed to send new match cycle messages to channel {channel_id}: {e}")
    
    # Store initial stats from message 1 for change tracking
    if season_15_data:
        ranked_s15 = season_15_data.get('ranked', {})
        state['initial_stats'] = {
            'kills': ranked_s15.get('k', 0),
            'deaths': ranked_s15.get('d', 0),
            'assists': ranked_s15.get('a', 0),
            'mmr': current_mmr
        }
    else:
        state['initial_stats'] = {'kills': 0, 'deaths': 0, 'assists': 0, 'mmr': current_mmr}
    
    # Player is not in match initially 
    state['in_ranked_match'] = False
    
    # MESSAGE 3: Send initial "not in ranked" status
    await send_initial_match_status(player_name, player_data)

async def send_initial_match_status(player_name: str, player_data: Dict[str, Any]):
    """Send initial message 3 showing player is not in ranked match yet"""
    if player_name not in player_states:
        return
    
    state = player_states[player_name]
    current_username = player_data.get('basicInfo', {}).get('name', player_name)
    
    # Create "not in match" embed
    embed = discord.Embed(
        title="ℹ️ **Match Status**",
        description=f"**{current_username}** is not currently in a ranked match",
        color=discord.Color.blue()
    )
    embed.add_field(name="**Status**", value="⚪ **Not in Match**", inline=True)
    embed.add_field(name="**Monitoring**", value="Waiting for ranked match to begin...", inline=True)
    
    # Send to all tracking channels and store message references
    channels = state['tracking_channels']
    active_messages = {}
    
    for channel_id in channels:
        try:
            channel = bot.get_channel(channel_id)
            if channel:
                sent_message = await channel.send(embed=embed)
                active_messages[channel_id] = sent_message
        except Exception as e:
            logger.error(f"Failed to send initial match status to channel {channel_id}: {e}")
    
    # Store message references for future editing
    state['active_match_messages'] = active_messages

async def send_ranked_status_message(player_name: str, player_data: Dict[str, Any]):
    """Send ranked status message (in match or not in match)"""
    if player_name not in player_states:
        return
    
    state = player_states[player_name]
    current_username = player_data.get('basicInfo', {}).get('name', player_name)
    
    # Check if player is actually in a ranked match
    is_in_match = is_player_in_ranked_match(player_data)
    
    if not is_in_match:
        # Send "not in match" message
        embed = discord.Embed(
            title="ℹ️ **Match Status**",
            description=f"**{current_username}** is not currently in a ranked match",
            color=discord.Color.blue()
        )
        embed.add_field(name="**Status**", value="⚪ **Not in Match**", inline=True)
        
        # Send to all tracking channels
        channels = state['tracking_channels']
        for channel_id in channels:
            try:
                channel = bot.get_channel(channel_id)
                if channel:
                    await channel.send("📊 **Match Check**", embed=embed)
            except Exception as e:
                logger.error(f"Failed to send match status to channel {channel_id}: {e}")
        return
    
    # Get current Season 15 ranked stats for match-specific tracking
    stats = player_data.get('stats', {})
    seasonal_stats = stats.get('seasonal_stats', [])
    season_15_data = None
    
    for season in seasonal_stats:
        if season.get('season') == 15:
            season_15_data = season
            break
    
    if not season_15_data:
        return
    
    ranked_s15 = season_15_data.get('ranked', {})
    
    # Store match start stats if not already stored
    if not state.get('match_start_stats'):
        last_stats = state.get('last_stats', {})
        if last_stats:
            last_stats_data = last_stats.get('stats', {})
            last_seasonal = last_stats_data.get('seasonal_stats', [])
            last_s15_data = None
            for season in last_seasonal:
                if season.get('season') == 15:
                    last_s15_data = season
                    break
            
            if last_s15_data:
                last_ranked = last_s15_data.get('ranked', {})
                state['match_start_stats'] = {
                    'k': last_ranked.get('k', 0),
                    'd': last_ranked.get('d', 0),
                    'a': last_ranked.get('a', 0)
                }
    
    # Calculate KDA changes from match start (what user requested)
    start_stats = state.get('match_start_stats', {'kills': 0, 'deaths': 0, 'assists': 0})
    current_kills = ranked_s15.get('k', 0)
    current_deaths = ranked_s15.get('d', 0) 
    current_assists = ranked_s15.get('a', 0)
    
    # Calculate the changes from match start
    kill_change = current_kills - start_stats['kills']
    death_change = current_deaths - start_stats['deaths']
    assist_change = current_assists - start_stats['assists']
    
    # Format changes with + for positive numbers  
    kill_text = f"+{kill_change}" if kill_change > 0 else str(kill_change)
    death_text = f"+{death_change}" if death_change > 0 else str(death_change)
    assist_text = f"+{assist_change}" if assist_change > 0 else str(assist_change)
    
    # Current KD ratio
    current_kd = round(current_kills / current_deaths, 2) if current_deaths > 0 else current_kills
    
    embed = discord.Embed(
        title="🔴 **LIVE RANKED MATCH**",
        description=f"**{current_username}** is currently in a ranked match",
        color=0xFFA500  # Orange color for live match
    )
    
    # Show total stats with changes since match start
    match_stats = f"**Total Kills:** {current_kills:,} ({kill_text})\n**Total Deaths:** {current_deaths:,} ({death_text})\n**Total Assists:** {current_assists:,} ({assist_text})\n**K/D:** {current_kd}"
    embed.add_field(name="🏆 Season 15 Match Stats", value=match_stats, inline=False)
    embed.add_field(
        name="📊 Live Tracking",
        value="This message updates automatically with KDA changes during the match",
        inline=False
    )
    
    # Look for existing "not in match" messages to edit instead of sending new ones
    channels = state['tracking_channels']
    active_messages = {}
    
    for channel_id in channels:
        try:
            channel = bot.get_channel(channel_id)
            if channel:
                # Look for recent messages to edit (check last 10 messages)
                message_to_edit = None
                async for message in channel.history(limit=10):
                    if (message.author == bot.user and 
                        message.embeds and 
                        ("not in match" in message.embeds[0].title.lower() or 
                         "currently in ranked" in message.embeds[0].title.lower())):
                        message_to_edit = message
                        break
                
                if message_to_edit:
                    # Edit existing message
                    await message_to_edit.edit(embed=embed)
                    active_messages[channel_id] = message_to_edit
                else:
                    # Send new message if no suitable message found
                    sent_message = await channel.send(embed=embed)
                    active_messages[channel_id] = sent_message
        except Exception as e:
            logger.error(f"Failed to send/edit ranked message in channel {channel_id}: {e}")
    
    # Update state
    state['in_ranked_match'] = True
    state['active_match_messages'] = active_messages
    state['last_match_kda'] = {'k': current_kills, 'd': current_deaths, 'a': current_assists}

async def update_ranked_match_message(player_name: str, player_data: Dict[str, Any]):
    """Update existing ranked match message with new KDA"""
    if player_name not in player_states:
        return
        
    state = player_states[player_name]
    if not state.get('in_ranked_match') or 'active_match_messages' not in state:
        return
    
    current_username = player_data.get('basicInfo', {}).get('name', player_name)
    
    # Get current Season 15 ranked stats
    stats = player_data.get('stats', {})
    seasonal_stats = stats.get('seasonal_stats', [])
    season_15_data = None
    
    for season in seasonal_stats:
        if season.get('season') == 15:
            season_15_data = season
            break
    
    if not season_15_data:
        return
    
    ranked_s15 = season_15_data.get('ranked', {})
    
    # Calculate KDA changes from match start (same as send_ranked_status_message)
    start_stats = state.get('match_start_stats', {'kills': 0, 'deaths': 0, 'assists': 0})
    current_kills = ranked_s15.get('k', 0)
    current_deaths = ranked_s15.get('d', 0) 
    current_assists = ranked_s15.get('a', 0)
    
    # Calculate the changes from match start
    kill_change = current_kills - start_stats['kills']
    death_change = current_deaths - start_stats['deaths']
    assist_change = current_assists - start_stats['assists']
    
    # Check if KDA changed
    last_kda = state.get('last_match_kda', {})
    if (current_kills != last_kda.get('k', 0) or current_deaths != last_kda.get('d', 0) or current_assists != last_kda.get('a', 0)):
        # Format changes with + for positive numbers  
        kill_text = f"+{kill_change}" if kill_change > 0 else str(kill_change)
        death_text = f"+{death_change}" if death_change > 0 else str(death_change)
        assist_text = f"+{assist_change}" if assist_change > 0 else str(assist_change)
        
        # Current KD ratio
        current_kd = round(current_kills / current_deaths, 2) if current_deaths > 0 else current_kills
        
        # Update the embed
        embed = discord.Embed(
            title="🔴 **LIVE RANKED MATCH**",
            description=f"**{current_username}** is currently in a ranked match",
            color=0xFFA500  # Orange color for live match
        )
        
        # Show total stats with changes since match start
        match_stats = f"**Total Kills:** {current_kills:,} ({kill_text})\n**Total Deaths:** {current_deaths:,} ({death_text})\n**Total Assists:** {current_assists:,} ({assist_text})\n**K/D:** {current_kd}"
        embed.add_field(name="🏆 Season 15 Match Stats", value=match_stats, inline=False)
        embed.add_field(
            name="📊 Live Tracking",
            value="This message updates automatically with KDA changes during the match",
            inline=False
        )
        
        # Edit all active match messages
        for channel_id, message in state['active_match_messages'].items():
            try:
                await message.edit(embed=embed)
            except Exception as e:
                logger.error(f"Failed to edit ranked message in channel {channel_id}: {e}")
        
        # Update stored KDA
        state['last_match_kda'] = {'k': current_kills, 'd': current_deaths, 'a': current_assists}

async def finalize_ranked_match(player_name: str, player_data: Dict[str, Any], mmr_change: int):
    """Finalize ranked match with final results"""
    if player_name not in player_states:
        return
        
    state = player_states[player_name]
    if not state.get('in_ranked_match') or 'active_match_messages' not in state:
        return
    
    current_username = player_data.get('basicInfo', {}).get('name', player_name)
    
    # Get final season stats
    stats = player_data.get('stats', {})
    seasonal_stats = stats.get('seasonal_stats', [])
    season_15_data = None
    
    for season in seasonal_stats:
        if season.get('season') == 15:
            season_15_data = season
            break
    
    if season_15_data:
        ranked_s15 = season_15_data.get('ranked', {})
        
        # Calculate final match-specific KDA changes
        start_stats = state.get('match_start_stats', {'kills': 0, 'deaths': 0, 'assists': 0})
        current_kills = ranked_s15.get('k', 0)
        current_deaths = ranked_s15.get('d', 0)
        current_assists = ranked_s15.get('a', 0)
        
        match_kills = current_kills - start_stats['kills']
        match_deaths = current_deaths - start_stats['deaths']
        match_assists = current_assists - start_stats['assists']
        
        # Ensure non-negative values
        match_kills = max(0, match_kills)
        match_deaths = max(0, match_deaths)
        match_assists = max(0, match_assists)
        
        wins = ranked_s15.get('w', 0)
        losses = ranked_s15.get('l', 0)
        kd_ratio = round(match_kills / match_deaths, 2) if match_deaths > 0 else match_kills
        
        # Get current MMR
        current_mmr = stats.get('ranked', {}).get('mmr', 0)
        
        change_symbol = "📈" if mmr_change > 0 else "📉"
        change_text = f"+{mmr_change}" if mmr_change > 0 else str(mmr_change)
        
        embed = discord.Embed(
            title="🏁 **Ranked Match Completed**",
            description=f"**{current_username}** finished their ranked match",
            color=discord.Color.green() if mmr_change > 0 else discord.Color.red()
        )
        embed.add_field(name="**Match KDA**", value=f"• **Kills:** {match_kills}\n• **Deaths:** {match_deaths}\n• **Assists:** {match_assists}", inline=False)
        embed.add_field(name="**MMR Change**", value=f"**{change_text} MMR**", inline=True)
        embed.add_field(name="**New MMR**", value=f"**{current_mmr:,}**", inline=True)
        embed.add_field(name="**Season 15 W/L**", value=f"**{wins}/{losses}**", inline=True)
        
        # Edit all active match messages with final results
        for channel_id, message in state['active_match_messages'].items():
            try:
                await message.edit(content=f"{change_symbol} **Match Completed**", embed=embed)
            except Exception as e:
                logger.error(f"Failed to edit final ranked message in channel {channel_id}: {e}")
        
        # Clean up match tracking
        state['in_ranked_match'] = False
        state['active_match_messages'] = {}
        state['last_match_kda'] = {}
        state['match_start_stats'] = {}

async def check_ranked_match_changes(player_name: str, current_data: Dict[str, Any], state: Dict[str, Any], current_mmr: int):
    """Check for ranked match state changes based on stat increases and MMR changes"""
    # Get current Season 15 stats
    stats = current_data.get('stats', {})
    seasonal_stats = stats.get('seasonal_stats', [])
    season_15_data = None
    
    for season in seasonal_stats:
        if season.get('season') == 15:
            season_15_data = season
            break
    
    if not season_15_data:
        return
    
    ranked_s15 = season_15_data.get('ranked', {})
    current_kills = ranked_s15.get('k', 0)
    current_deaths = ranked_s15.get('d', 0)
    current_assists = ranked_s15.get('a', 0)
    
    # Get initial stats from message 1
    initial_stats = state.get('initial_stats', {})
    initial_kills = initial_stats.get('kills', current_kills)
    initial_deaths = initial_stats.get('deaths', current_deaths)
    initial_assists = initial_stats.get('assists', current_assists)
    initial_mmr = initial_stats.get('mmr', current_mmr)
    
    was_in_match = state.get('in_ranked_match', False)
    
    # Debug logging
    logger.info(f"Debug {player_name}: Current K/D/A: {current_kills}/{current_deaths}/{current_assists}, Initial: {initial_kills}/{initial_deaths}/{initial_assists}")
    logger.info(f"Debug {player_name}: Current MMR: {current_mmr}, Initial MMR: {initial_mmr}, In match: {was_in_match}")
    
    # Check if MMR changed (match ended)
    if current_mmr != initial_mmr and was_in_match:
        # Match ended - finalize with MMR change
        mmr_change = current_mmr - initial_mmr
        logger.info(f"Debug {player_name}: Match ended, MMR change: {mmr_change}")
        await finalize_ranked_match(player_name, current_data, mmr_change)
        
        # Reset for potential new match detection
        state['in_ranked_match'] = False
        state['initial_stats']['mmr'] = current_mmr
        state['initial_stats']['kills'] = current_kills
        state['initial_stats']['deaths'] = current_deaths  
        state['initial_stats']['assists'] = current_assists
        return
    
    # Check if ranked stats increased (entered match or match progressing)
    stats_increased = (current_kills > initial_kills or 
                      current_deaths > initial_deaths or 
                      current_assists > initial_assists)
    
    logger.info(f"Debug {player_name}: Stats increased: {stats_increased}")
    
    if stats_increased and not was_in_match:
        # Player just entered a ranked match
        logger.info(f"Debug {player_name}: Player entered ranked match")
        state['in_ranked_match'] = True
        await edit_message_to_live_match(player_name, current_data)
    elif stats_increased and was_in_match:
        # Player still in match, update live KDA
        logger.info(f"Debug {player_name}: Updating live match")
        await update_live_match_message(player_name, current_data)

async def edit_message_to_live_match(player_name: str, player_data: Dict[str, Any]):
    """Edit message 3 to show player entered ranked match"""
    if player_name not in player_states:
        return
    
    state = player_states[player_name]
    current_username = player_data.get('basicInfo', {}).get('name', player_name)
    
    # Get current Season 15 stats
    stats = player_data.get('stats', {})
    seasonal_stats = stats.get('seasonal_stats', [])
    season_15_data = None
    
    for season in seasonal_stats:
        if season.get('season') == 15:
            season_15_data = season
            break
    
    if not season_15_data:
        return
    
    ranked_s15 = season_15_data.get('ranked', {})
    current_kills = ranked_s15.get('k', 0)
    current_deaths = ranked_s15.get('d', 0)
    current_assists = ranked_s15.get('a', 0)
    
    # Calculate changes from initial stats
    initial_stats = state.get('initial_stats', {})
    kill_change = current_kills - initial_stats.get('kills', 0)
    death_change = current_deaths - initial_stats.get('deaths', 0)
    assist_change = current_assists - initial_stats.get('assists', 0)
    
    # Current KD ratio
    current_kd = round(current_kills / current_deaths, 2) if current_deaths > 0 else current_kills
    
    embed = discord.Embed(
        title="🔴 **LIVE RANKED MATCH**",
        description=f"**{current_username}** is currently in a ranked match",
        color=0xFFA500  # Orange color for live match
    )
    
    # Show match KDA changes (only the changes, not totals)
    match_stats = f"**Kills:** {kill_change}\n**Deaths:** {death_change}\n**Assists:** {assist_change}\n**Current K/D:** {current_kd}"
    embed.add_field(name="🏆 Match KDA", value=match_stats, inline=False)
    embed.add_field(
        name="📊 Live Tracking",
        value="This message updates automatically with KDA changes during the match",
        inline=False
    )
    
    # Edit all active match messages
    active_messages = state.get('active_match_messages', {})
    for channel_id, message in active_messages.items():
        try:
            await message.edit(embed=embed)
        except Exception as e:
            logger.error(f"Failed to edit match message in channel {channel_id}: {e}")

async def update_live_match_message(player_name: str, player_data: Dict[str, Any]):
    """Update live match message with current KDA changes"""
    # Same logic as edit_message_to_live_match
    await edit_message_to_live_match(player_name, player_data)

async def check_player_updates():
    """Background task to monitor tracked players for changes"""
    while True:
        try:
            for player_name, state in list(player_states.items()):
                # Use different intervals for players in ranked matches
                if state.get('in_ranked_match'):
                    # Check every 1-2 minutes for active matches
                    if datetime.utcnow() - state['last_check_time'] < timedelta(minutes=1):
                        continue
                else:
                    # Only check players that have been checked more than 30 seconds ago
                    if datetime.utcnow() - state['last_check_time'] < timedelta(seconds=30):
                        continue
                    
                # Fetch current player data
                current_data = await get_player_stats(state['last_username'])
                if not current_data:
                    continue
                    
                # Update last check time
                state['last_check_time'] = datetime.utcnow()
                
                # Check for username changes
                current_username = current_data.get('basicInfo', {}).get('name', state['last_username'])
                if current_username != state['last_username']:
                    embed = discord.Embed(
                        title="📝 Username Changed",
                        description=f"**{state['last_username']}** changed their name to **{current_username}**",
                        color=0xFFAA00
                    )
                    await send_notification_to_trackers(player_name, f"🔄 **Username Update**", embed)
                    
                    # Update stored username
                    state['last_username'] = current_username
                
                # Check for ban status changes
                current_ban = current_data.get('ban')
                last_ban = state.get('last_ban_status')
                
                if current_ban != last_ban:
                    if current_ban:  # Player got banned
                        ban_reason = current_ban.get('reason', 'Unknown')
                        ban_type = current_ban.get('type', 'Unknown')
                        ban_expires = current_ban.get('expires_at', 'Permanent')
                        
                        if ban_expires and ban_expires != 'Permanent':
                            ban_duration = f"Until {ban_expires}"
                        else:
                            ban_duration = "Permanent"
                            
                        embed = discord.Embed(
                            title="⚠️ Player Banned",
                            description=f"**{current_username}** has been banned from Critical Ops",
                            color=0xFF4444
                        )
                        embed.add_field(name="Reason", value=ban_reason, inline=True)
                        embed.add_field(name="Type", value=ban_type, inline=True)
                        embed.add_field(name="Duration", value=ban_duration, inline=True)
                        
                        await send_notification_to_trackers(player_name, f"🚫 **Ban Alert**", embed)
                    else:  # Player got unbanned
                        embed = discord.Embed(
                            title="✅ Player Unbanned",
                            description=f"**{current_username}** is no longer banned",
                            color=0x00FF00
                        )
                        await send_notification_to_trackers(player_name, f"🎉 **Unban Alert**", embed)
                
                # Check for MMR/ranked changes and match status
                current_stats = current_data.get('stats', {})
                current_ranked = current_stats.get('ranked', {})
                current_mmr = current_ranked.get('mmr', 0)
                
                last_mmr = state.get('last_mmr')
                
                # Check for ranked match changes based on user's logic
                await check_ranked_match_changes(player_name, current_data, state, current_mmr)
                

                
                # Update stored states
                state['last_stats'] = current_data
                state['last_ban_status'] = current_ban
                state['last_mmr'] = current_mmr if current_mmr > 0 else None
                
        except Exception as e:
            logger.error(f"Error in background monitoring: {e}")
        
        # Wait 30 seconds before next check (or 1 minute for active matches)
        await asyncio.sleep(30)

@bot.event
async def on_ready():
    """Bot startup event"""
    logger.info(f'{bot.user} has connected to Discord!')
    logger.info(f'Owner ID: {DISCORD_OWNER_ID}')
    
    try:
        # Sync commands globally to work in DMs and group chats
        synced = await bot.tree.sync()
        logger.info(f'Synced {len(synced)} command(s) globally')
        
        # Start background monitoring task
        asyncio.create_task(check_player_updates())
        logger.info("Started background player monitoring task")
    except Exception as e:
        logger.error(f'Failed to sync commands: {e}')

@bot.event
async def on_message(message):
    """Listen and respond to messages in DMs and group chats"""
    if message.author.bot:
        return  # ignore bots
    
    # This works for GCs and DMs, no extra filters needed
    channel_type = str(message.channel.type)
    logger.info(f'Message from {message.author.name} in {channel_type}: {message.content}')
    
    # Process commands for both slash and text commands
    await bot.process_commands(message)

@bot.tree.command(name="snipe", description="Track a Critical Ops player's stats")
@discord.app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
async def snipe_player(interaction: discord.Interaction, player_name: str):
    """Track a Critical Ops player - Available to authorized users"""
    # Log interaction details for debugging
    channel_type = str(interaction.channel.type) if interaction.channel else "Unknown"
    logger.info(f"Snipe command from {interaction.user.name} ({interaction.user.id}) in {channel_type}")
    logger.info(f"Current authorized users: {AUTHORIZED_USERS}")
    
    # Check authorization using hardcoded list
    if interaction.user.id not in AUTHORIZED_USERS:
        logger.warning(f"Unauthorized access attempt by {interaction.user.name} ({interaction.user.id})")
        await interaction.response.send_message("You are not authorized to use this command.", ephemeral=True)
        return
    
    await interaction.response.defer()
    
    try:
        # Fetch player data from Critical Ops API
        data = await get_player_stats(player_name)
        
        if not data:
            await interaction.followup.send("❌ Player not found or API error.")
            return
        
        # Use the correct API response format from the working code
        player_info = data
        
        # Debug: Log API response structure
        logger.info(f"API Response keys: {list(player_info.keys())}")
        if 'stats' in player_info:
            logger.info(f"Stats keys: {list(player_info['stats'].keys())}")
        if 'seasonal_stats' in player_info.get('stats', {}):
            logger.info(f"Found seasonal_stats with {len(player_info['stats']['seasonal_stats'])} seasons")
        
        # Extract player information using correct API structure
        basic_info = player_info.get('basicInfo', {})
        username = basic_info.get('name', player_name)
        level_data = basic_info.get('playerLevel', 'N/A')
        if isinstance(level_data, dict):
            level = level_data.get('level', 'N/A')
        else:
            level = level_data
        clan_tag = basic_info.get('clan', {}).get('tag', 'N/A')
        
        # Get ban status
        ban_data = player_info.get('ban')
        ban_status = format_ban_status(ban_data)
        
        # Extract stats
        stats = player_info.get('stats', {})
        
        # Get seasonal stats for calculations
        seasonal_stats = stats.get('seasonal_stats', [])
        
        # Calculate total casual stats (casual mode only, excluding custom and ranked)
        total_kills = total_deaths = total_assists = 0
        for season in seasonal_stats:
            casual_data = season.get('casual', {})
            total_kills += casual_data.get('k', 0)
            total_deaths += casual_data.get('d', 0) 
            total_assists += casual_data.get('a', 0)
        
        total_kd = round(total_kills / total_deaths, 2) if total_deaths > 0 else total_kills
        
        # Current ranked stats
        ranked_stats = stats.get('ranked', {})
        current_mmr = ranked_stats.get('mmr', 0)
        
        # Season 15 ranked stats
        season_15_data = None
        for season in seasonal_stats:
            if season.get('season') == 15:
                season_15_data = season
                break
        
        if season_15_data:
            ranked_s15 = season_15_data.get('ranked', {})
            s15_kills = ranked_s15.get('k', 0)
            s15_deaths = ranked_s15.get('d', 0)
            s15_assists = ranked_s15.get('a', 0)
            s15_wins = ranked_s15.get('w', 0)
            s15_losses = ranked_s15.get('l', 0)
            s15_kd = round(s15_kills / s15_deaths, 2) if s15_deaths > 0 else s15_kills
        else:
            s15_kills = s15_deaths = s15_assists = s15_wins = s15_losses = 0
            s15_kd = 0.0
        
        # Get account ID and clan info  
        account_id = basic_info.get('userID', 'N/A')
        clan_info = player_info.get('clan', {}).get('basicInfo', {})
        clan_tag = clan_info.get('tag', 'N/A')
        clan_name = clan_info.get('name', '')
        
        # Format clan display as [Tag] - Name
        if clan_tag != 'N/A' and clan_name:
            clan_display = f"[{clan_tag}] - {clan_name}"
        elif clan_tag != 'N/A':
            clan_display = clan_tag
        else:
            clan_display = 'N/A'
        
        # Create enhanced embed with PINK color instead of teal
        embed = discord.Embed(
            title=f"🦧 **{username} — Season 15**",
            color=discord.Color.magenta()  # Changed from discord.Color.teal() to pink
        )
        
        # Player info section
        player_info_text = f"🆔 **Account ID:** {account_id}\n🏷️ **Clan:** {clan_display}\n📋 **Ban Status:** {ban_status}"
        embed.add_field(name="", value=player_info_text, inline=False)
        
        # ELO and Level section
        elo_level_text = f"🏅 **ELO:** {current_mmr:,}\n📊 **Level:** {level}"
        embed.add_field(name="", value=elo_level_text, inline=False)
        
        # Casual Stats section (using overall stats)
        casual_stats_text = f"• **Kills:** {total_kills:,}\n• **Deaths:** {total_deaths:,}\n• **Assists:** {total_assists:,}\n• **K/D Ratio:** {total_kd}"
        embed.add_field(name="⚔️ **Casual Stats**", value=casual_stats_text, inline=False)
        
        # Ranked Stats section (Season 15 only, displayed below casual)  
        ranked_stats_text = f"• **Kills:** {s15_kills:,}\n• **Deaths:** {s15_deaths:,}\n• **Assists:** {s15_assists:,}\n• **Wins:** {s15_wins}\n• **Losses:** {s15_losses}\n• **K/D Ratio:** {s15_kd}"
        embed.add_field(name="🏆 **Ranked Stats (S15)**", value=ranked_stats_text, inline=False)
        
        # Add ban details if player is banned
        if ban_data:
            ban_reasons = {
                1: "Cheating",
                2: "Abusive Behavior", 
                3: "Exploiting",
                4: "Team Killing",
                5: "Inappropriate Name",
                6: "Spam",
                7: "Other"
            }
            reason_id = ban_data.get('Reason', ban_data.get('reason', 0))
            ban_reason = ban_reasons.get(reason_id, "Unknown")
            embed.add_field(name="🚫 **Banned**", value=f"**Reason:** {ban_reason}", inline=False)

        await interaction.followup.send(embed=embed)
        
        # Track this player for the user
        user_id = interaction.user.id
        if user_id not in tracked_players:
            tracked_players[user_id] = []
        
        if player_name not in tracked_players[user_id]:
            tracked_players[user_id].append(player_name)
        
        # Initialize player state for monitoring
        if player_name not in player_states:
            player_states[player_name] = {
                'last_stats': data,
                'last_check_time': datetime.utcnow(),
                'tracking_channels': [],
                'last_username': username,
                'last_ban_status': ban_data,
                'last_mmr': current_mmr if current_mmr > 0 else None,
                'in_ranked_match': False,
                'active_match_messages': {},
                'last_match_kda': {},
                'match_start_stats': {}
            }
        
        # Add this channel to tracking list
        if interaction.channel and interaction.channel.id not in player_states[player_name]['tracking_channels']:
            player_states[player_name]['tracking_channels'].append(interaction.channel.id)
        
        # Send tracking confirmation
        tracking_embed = discord.Embed(
            title="🟢 Now Tracking",
            description=f"**{username}** is now being monitored for updates",
            color=0x00FF00
        )
        tracking_embed.add_field(
            name="Monitoring Features:",
            value="• 🏆 Ranked match notifications (KDA, MMR changes)\n• ⚠️ Ban status alerts (reason, duration)\n• 📝 Username change notifications\n• 📊 Real-time stat updates",
            inline=False
        )
        tracking_embed.add_field(
            name="Stop Tracking",
            value=f"Use `/unsnipe {username}` to stop tracking.",
            inline=False
        )
        
        await interaction.followup.send(embed=tracking_embed)
        
        # Check if player is currently in a ranked match and send status
        await send_ranked_status_message(player_name, data)
        
    except Exception as e:
        logger.error(f"Error in snipe command: {e}")
        await interaction.followup.send("❌ An error occurred while fetching player data.")

@bot.tree.command(name="unsnipe", description="Stop tracking a Critical Ops player")
@discord.app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
async def unsnipe_player(interaction: discord.Interaction, player_name: str):
    """Stop tracking a Critical Ops player - Available to authorized users"""
    # Check authorization
    if interaction.user.id not in AUTHORIZED_USERS:
        await interaction.response.send_message("You are not authorized to use this command.", ephemeral=True)
        return
    
    user_id = interaction.user.id
    
    # Remove player from user's tracking list
    if user_id in tracked_players and player_name in tracked_players[user_id]:
        tracked_players[user_id].remove(player_name)
        
        # Remove channel from player's tracking channels
        if player_name in player_states and interaction.channel:
            if interaction.channel.id in player_states[player_name]['tracking_channels']:
                player_states[player_name]['tracking_channels'].remove(interaction.channel.id)
            
            # If no one is tracking this player anymore, remove from states
            if not player_states[player_name]['tracking_channels']:
                del player_states[player_name]
        
        embed = discord.Embed(
            title="🔴 Stopped Tracking",
            description=f"No longer monitoring **{player_name}**",
            color=0xFF4444
        )
        await interaction.response.send_message(embed=embed)
    else:
        await interaction.response.send_message(f"❌ You are not currently tracking **{player_name}**.")

@bot.tree.command(name="list", description="Show your tracked players")
@discord.app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
async def list_tracked_players(interaction: discord.Interaction):
    """List all players you're currently tracking"""
    if interaction.user.id not in AUTHORIZED_USERS:
        await interaction.response.send_message("You are not authorized to use this command.", ephemeral=True)
        return
    
    user_id = interaction.user.id
    
    if user_id not in tracked_players or not tracked_players[user_id]:
        embed = discord.Embed(
            title="📋 Your Tracked Players",
            description="You are not currently tracking any players.",
            color=0x888888
        )
        embed.add_field(name="Start Tracking", value="Use `/snipe [player_name]` to start tracking a player.", inline=False)
        await interaction.response.send_message(embed=embed)
        return
    
    players_list = "\n".join([f"• **{player}**" for player in tracked_players[user_id]])
    
    embed = discord.Embed(
        title="📋 Your Tracked Players",
        description=players_list,
        color=0x00FFFF
    )
    embed.add_field(name="Stop Tracking", value="Use `/unsnipe [player_name]` to stop tracking a player.", inline=False)
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="authorize", description="Authorize a user to use bot commands (Owner only)")
@discord.app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
async def authorize_user(interaction: discord.Interaction, user: discord.User):
    """Authorize a user to use bot commands - Owner only"""
    if not is_owner(interaction.user.id):
        await interaction.response.send_message("❌ Only the bot owner can use this command.", ephemeral=True)
        return
    
    if user.id in AUTHORIZED_USERS:
        await interaction.response.send_message(f"✅ **{user.name}** is already authorized.", ephemeral=True)
        return
    
    AUTHORIZED_USERS.add(user.id)
    
    embed = discord.Embed(
        title="✅ User Authorized",
        description=f"**{user.name}** ({user.id}) can now use bot commands.",
        color=0x00FF00
    )
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="deauthorize", description="Remove user authorization (Owner only)")
@discord.app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
async def deauthorize_user(interaction: discord.Interaction, user: discord.User):
    """Remove user authorization - Owner only"""
    if not is_owner(interaction.user.id):
        await interaction.response.send_message("❌ Only the bot owner can use this command.", ephemeral=True)
        return
    
    if user.id == DISCORD_OWNER_ID:
        await interaction.response.send_message("❌ Cannot deauthorize the bot owner.", ephemeral=True)
        return
    
    if user.id not in AUTHORIZED_USERS:
        await interaction.response.send_message(f"❌ **{user.name}** is not currently authorized.", ephemeral=True)
        return
    
    AUTHORIZED_USERS.remove(user.id)
    
    embed = discord.Embed(
        title="🔴 User Deauthorized",
        description=f"**{user.name}** ({user.id}) can no longer use bot commands.",
        color=0xFF4444
    )
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="userlist", description="List all authorized users (Owner only)")
@discord.app_commands.allowed_contexts(guilds=True, dms=True, private_channels=True)
async def list_authorized_users(interaction: discord.Interaction):
    """List all authorized users - Owner only"""
    if not is_owner(interaction.user.id):
        await interaction.response.send_message("❌ Only the bot owner can use this command.", ephemeral=True)
        return
    
    if not AUTHORIZED_USERS:
        embed = discord.Embed(
            title="👥 Authorized Users",
            description="No users are currently authorized.",
            color=0x888888
        )
        await interaction.response.send_message(embed=embed)
        return
    
    user_list = []
    for user_id in AUTHORIZED_USERS:
        try:
            user = await bot.fetch_user(user_id)
            status = "👑 Owner" if user_id == DISCORD_OWNER_ID else "✅ Authorized"
            user_list.append(f"• **{user.name}** ({user_id}) - {status}")
        except:
            user_list.append(f"• **Unknown User** ({user_id}) - ✅ Authorized")
    
    embed = discord.Embed(
        title="👥 Authorized Users",
        description="\n".join(user_list),
        color=0x00FFFF
    )
    await interaction.response.send_message(embed=embed)

if __name__ == "__main__":
    try:
        bot.run(DISCORD_BOT_TOKEN)
    except Exception as e:
        logger.error(f"Failed to start bot: {e}")
