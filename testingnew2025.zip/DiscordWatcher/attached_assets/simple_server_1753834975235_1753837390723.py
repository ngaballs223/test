import http.server
import socketserver
import json
import os
from datetime import datetime

PORT = 5000

class HealthHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/health':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            
            response = {
                'status': 'ok',
                'timestamp': datetime.now().isoformat(),
                'bot_running': True  # Assume bot is running if this server is up
            }
            
            self.wfile.write(json.dumps(response).encode())
            
        elif self.path == '/api/status':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            
            response = {
                'server': 'running',
                'bot': 'running',
                'timestamp': datetime.now().isoformat()
            }
            
            self.wfile.write(json.dumps(response).encode())
            
        else:
            # Serve a simple status page
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            
            html = """
            <!DOCTYPE html>
            <html>
            <head>
                <title>Critical Ops Discord Bot - Enhanced</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 40px; background: #1a1a1a; color: #fff; }
                    .container { max-width: 600px; margin: 0 auto; text-align: center; }
                    .status { background: #2a2a2a; padding: 20px; border-radius: 8px; margin: 20px 0; }
                    .emoji { font-size: 2em; margin: 10px; }
                    a { color: #4CAF50; text-decoration: none; }
                    .feature { background: #333; padding: 15px; border-radius: 6px; margin: 10px 0; }
                    .new-feature { background: #004d40; border-left: 4px solid #00ffff; }
                    .url { background: #444; padding: 10px; border-radius: 4px; margin: 20px 0; font-family: monospace; }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>🦧 Critical Ops Discord Bot - Enhanced</h1>
                    <div class="status">
                        <div class="emoji">🟢</div>
                        <h2>Bot is Online with Live Match Tracking!</h2>
                        <p>Now featuring real-time ranked match monitoring and enhanced ban status display</p>
                    </div>
                    
                    <div class="feature new-feature">
                        <h3>🆕 New Features</h3>
                        <p><strong>🏆 Live Ranked Match Tracking</strong> - Real-time KDA updates during matches</p>
                        <p><strong>⚠️ Enhanced Ban Status Display</strong> - Shows ban information in player stats</p>
                        <p><strong>📊 Real-time Match Updates</strong> - Live message editing with current KDA</p>
                        <p><strong>🏁 Match Completion Results</strong> - Final scores and MMR changes</p>
                    </div>
                    
                    <div class="feature">
                        <h3>Available Commands (Discord)</h3>
                        <p><strong>/snipe [player_name]</strong> - Track a player with enhanced ban status display</p>
                        <p><strong>/authorize [@user]</strong> - Add user permissions (Owner only)</p>
                        <p><strong>/deauthorize [@user]</strong> - Remove user permissions (Owner only)</p>
                        <p><strong>/userlist</strong> - View authorized users (Owner only)</p>
                        <p><strong>/list</strong> - Show your tracked players</p>
                        <p><strong>/unsnipe [player_name]</strong> - Stop tracking a player</p>
                    </div>
                    
                    <div class="feature">
                        <h3>Enhanced Monitoring Features</h3>
                        <p>✅ Player stats now include ban status (N/A, Temporary, or Permanent)</p>
                        <p>✅ Live ranked match detection and KDA tracking</p>
                        <p>✅ Real-time message updates during active matches (1-2 minute intervals)</p>
                        <p>✅ Final match results with MMR changes displayed</p>
                        <p>✅ Username change notifications</p>
                        <p>✅ Ban/unban alerts with detailed information</p>
                        <p>✅ All existing functionality preserved</p>
                    </div>
                    
                    <div class="feature">
                        <h3>Live Match Tracking Process</h3>
                        <p>1. <strong>Detection:</strong> Bot detects when tracked player enters ranked match</p>
                        <p>2. <strong>Live Updates:</strong> KDA is updated every 1-2 minutes during the match</p>
                        <p>3. <strong>Message Editing:</strong> Same message is edited with current KDA stats</p>
                        <p>4. <strong>Match Completion:</strong> Final results show total KDA and MMR gained/lost</p>
                    </div>
                    
                    <div class="feature">
                        <h3>Health Endpoints</h3>
                        <p><a href="/health">Health Check</a></p>
                        <p><a href="/api/status">API Status</a></p>
                    </div>
                    
                    <p style="margin-top: 40px; color: #888;">
                        Enhanced Discord bot with live ranked match tracking and ban status display!
                    </p>
                </div>
            </body>
            </html>
            """
            
            self.wfile.write(html.encode())

if __name__ == "__main__":
    with socketserver.TCPServer(("0.0.0.0", PORT), HealthHandler) as httpd:
        print(f"Enhanced server running on port {PORT}")
        print(f"Health check: http://0.0.0.0:{PORT}/health")
        print(f"Status page: http://0.0.0.0:{PORT}/")
        httpd.serve_forever()
