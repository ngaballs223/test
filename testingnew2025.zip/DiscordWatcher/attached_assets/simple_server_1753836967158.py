import http.server
import socketserver
import json
import os
from datetime import datetime

PORT = 5000

class HealthHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/health':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            
            response = {
                'status': 'ok',
                'timestamp': datetime.now().isoformat(),
                'bot_running': True  # Assume bot is running if this server is up
            }
            
            self.wfile.write(json.dumps(response).encode())
            
        elif self.path == '/api/status':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            
            response = {
                'server': 'running',
                'bot': 'running',
                'timestamp': datetime.now().isoformat()
            }
            
            self.wfile.write(json.dumps(response).encode())
            
        else:
            # Serve a simple status page
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            
            html = """
            <!DOCTYPE html>
            <html>
            <head>
                <title>Critical Ops Discord Bot - Account ID Tracking & Enhanced Features</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 40px; background: #1a1a1a; color: #fff; }
                    .container { max-width: 800px; margin: 0 auto; text-align: center; }
                    .status { background: #2a2a2a; padding: 20px; border-radius: 8px; margin: 20px 0; }
                    .emoji { font-size: 2em; margin: 10px; }
                    a { color: #4CAF50; text-decoration: none; }
                    .feature { background: #333; padding: 15px; border-radius: 6px; margin: 10px 0; }
                    .new-feature { background: #004d40; border-left: 4px solid #00ffff; }
                    .fix-feature { background: #1b5e20; border-left: 4px solid #4caf50; }
                    .url { background: #444; padding: 10px; border-radius: 4px; margin: 20px 0; font-family: monospace; }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>🦧 Critical Ops Discord Bot - Account ID Tracking System</h1>
                    <div class="status">
                        <div class="emoji">🔥</div>
                        <h2>Bot is Online with Account ID Tracking!</h2>
                        <p>Now featuring persistent player monitoring, enhanced match formatting, and automatic permanent ban handling</p>
                    </div>
                    
                    <div class="feature new-feature">
                        <h3>🆕 Latest Features - Account ID Based Tracking</h3>
                        <p><strong>🆔 Account ID Tracking</strong> - Players tracked by Account ID for persistent monitoring</p>
                        <p><strong>📝 Username Change Detection</strong> - Automatic notifications when players change usernames</p>
                        <p><strong>⚠️ Ban Status Monitoring</strong> - Real-time ban status change notifications</p>
                        <p><strong>💀 Permanent Ban Auto-Stop</strong> - Custom ASCII art and automatic removal from tracking</p>
                        <p><strong>📊 Enhanced Match Display</strong> - Clean KDA without "+" symbols, K/D ratio to 2 decimal places</p>
                        <p><strong>🏆 Win Rate Tracking</strong> - Wins, losses, and win rate percentage in live matches</p>
                    </div>
                    
                    <div class="feature fix-feature">
                        <h3>🔧 Enhanced Match Formatting</h3>
                        <p><strong>✅ Clean KDA Display</strong> - Removed "+" symbols from kills and deaths</p>
                        <p><strong>✅ Precise K/D Ratio</strong> - K/D ratio displayed to exactly 2 decimal places (e.g., 1.23)</p>
                        <p><strong>✅ Win Rate Statistics</strong> - Shows wins, losses, and calculated win rate percentage</p>
                        <p><strong>✅ Match Duration</strong> - Live match timer with minutes and seconds</p>
                        <p><strong>✅ Visual Status States</strong> - Clear match status indicators throughout lifecycle</p>
                    </div>
                    
                    <div class="feature">
                        <h3>🛡️ Account ID Based Monitoring</h3>
                        <p><strong>Persistent Tracking:</strong> Players tracked by Account ID, not username</p>
                        <p><strong>Username Changes:</strong> Automatic detection and notification of name changes</p>
                        <p><strong>Ban Monitoring:</strong> Real-time ban status change detection and alerts</p>
                        <p><strong>Permanent Ban Handling:</strong> Custom ASCII art skull and auto-removal from tracking</p>
                        <p><strong>Change Detection:</strong> Only sends notifications when actual changes occur</p>
                    </div>
                    
                    <div class="feature">
                        <h3>Available Commands (Discord)</h3>
                        <p><strong>/snipe [player_name]</strong> - Start tracking with Account ID-based system</p>
                        <p><strong>/unsnipe [player_name]</strong> - Stop tracking a player</p>
                        <p><strong>/list</strong> - Show your tracked players</p>
                        <p><strong>/authorize [@user]</strong> - Add user permissions (Owner only)</p>
                        <p><strong>/deauthorize [@user]</strong> - Remove user permissions (Owner only)</p>
                        <p><strong>/userlist</strong> - View authorized users (Owner only)</p>
                    </div>
                    
                    <div class="feature">
                        <h3>🎯 Test Notifications for Account ID 31357194</h3>
                        <p><strong>Test Scenario 1:</strong> Permanent ban notification for cheating with ASCII art</p>
                        <p><strong>Test Scenario 2:</strong> Username change from "OldPlayerName" to "LuciferDonk666"</p>
                        <p><strong>Auto-Generated:</strong> Test messages prepared on bot startup</p>
                    </div>
                    
                    <div class="feature">
                        <h3>💀 Permanent Ban Auto-Stop Features</h3>
                        <p>🎨 Custom ASCII skull art with "RIP" styling</p>
                        <p>🛑 Automatic removal from all tracking lists</p>
                        <p>📢 Notification to all tracking channels</p>
                        <p>🔄 Clean state management and memory cleanup</p>
                    </div>
                    
                    <div class="feature">
                        <h3>Technical Improvements</h3>
                        <p>✅ Account ID-based player state storage</p>
                        <p>✅ Change detection logic for bans and usernames</p>
                        <p>✅ Enhanced match formatting without "+" symbols</p>
                        <p>✅ K/D ratio calculated to exactly 2 decimal places</p>
                        <p>✅ Win rate percentage calculation and display</p>
                        <p>✅ Silent monitoring with event-driven notifications</p>
                        <p>✅ Custom ASCII art for permanent ban notifications</p>
                        <p>✅ Automatic cleanup of permanently banned players</p>
                        <p>✅ Persistent tracking across username changes</p>
                    </div>
                    
                    <div class="feature">
                        <h3>Health Endpoints</h3>
                        <p><a href="/health">Health Check</a></p>
                        <p><a href="/api/status">API Status</a></p>
                    </div>
                    
                    <p style="margin-top: 40px; color: #888;">
                        Enhanced Discord bot with Account ID tracking, clean match formatting, and permanent ban auto-stop!
                    </p>
                </div>
            </body>
            </html>
            """
            
            self.wfile.write(html.encode())

if __name__ == "__main__":
    with socketserver.TCPServer(("0.0.0.0", PORT), HealthHandler) as httpd:
        print(f"Enhanced server running on port {PORT}")
        print(f"Health check: http://0.0.0.0:{PORT}/health")
        print(f"Status page: http://0.0.0.0:{PORT}/")
        httpd.serve_forever()
