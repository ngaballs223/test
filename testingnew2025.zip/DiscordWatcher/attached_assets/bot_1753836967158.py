import discord
from discord.ext import commands
import aiohttp
import asyncio
import logging
import os
from datetime import datetime, timedelta
from typing import Dict, Any, Optional

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Environment variables
DISCORD_BOT_TOKEN = os.getenv("DISCORD_BOT_TOKEN")
DISCORD_OWNER_ID = int(os.getenv("DISCORD_OWNER_ID", "0"))

if not DISCORD_BOT_TOKEN:
    logger.error("DISCORD_BOT_TOKEN environment variable is required!")
    exit(1)

# Hardcoded authorized user IDs (modify this list as needed)
AUTHORIZED_USERS = {
    DISCORD_OWNER_ID,  # Bot owner is always authorized
    931954020766081054,  # ididntwannachange
    1231303599687073863,
    1231259717574201374,
    669054801660870668,
    486552200143699974,
    998422652635058257,
    776214689255915520
}

# Remove 0 from authorized users if no owner ID was set
if DISCORD_OWNER_ID == 0:
    AUTHORIZED_USERS.discard(0)

# Bot configuration
intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True
intents.dm_messages = True

bot = commands.Bot(command_prefix='!', intents=intents)

# Global storage for tracked players and their states
tracked_players = {}  # {user_id: [player_names]}
player_states = {}    # {account_id: {last_stats, last_check_time, tracking_channels, etc.}}

def is_owner(user_id: int) -> bool:
    """Check if user is the bot owner"""
    return user_id == DISCORD_OWNER_ID and DISCORD_OWNER_ID != 0

def format_ban_status(ban_data: Optional[Dict[str, Any]]) -> str:
    """Format ban status for display"""
    if not ban_data:
        return "N/A"
    
    ban_type = ban_data.get('type', ban_data.get('Type', 'Unknown'))
    if ban_type == 'Temporary':
        expires = ban_data.get('expires_at', ban_data.get('ExpiresAt', 'Unknown'))
        return f"Temporary (expires: {expires})"
    elif ban_type == 'Permanent':
        return "Permanent"
    else:
        return ban_type

async def get_player_stats(player_name: str) -> Optional[Dict[str, Any]]:
    """Fetch player statistics from Critical Ops API"""
    try:
        # Use the correct working API endpoint from the original code
        url = f"https://api-cops.criticalforce.fi/api/public/profile?usernames={player_name}"
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    # API returns array, get first player
                    if data and len(data) > 0:
                        return data[0]
                    else:
                        logger.error(f"No player data found for {player_name}")
                        return None
                else:
                    logger.error(f"API request failed with status {response.status}")
                    return None
    except Exception as e:
        logger.error(f"Error fetching stats for {player_name}: {e}")
        return None

async def get_player_stats_by_id(account_id: str) -> Optional[Dict[str, Any]]:
    """Fetch player statistics by Account ID from Critical Ops API"""
    try:
        url = f"https://api-cops.criticalforce.fi/api/public/profile?userids={account_id}"
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    # API returns array, get first player
                    if data and len(data) > 0:
                        return data[0]
                    else:
                        logger.error(f"No player data found for account ID {account_id}")
                        return None
                else:
                    logger.error(f"API request failed with status {response.status}")
                    return None
    except Exception as e:
        logger.error(f"Error fetching stats for account ID {account_id}: {e}")
        return None

async def send_notification_to_trackers(account_id: str, content: str, embed: discord.Embed):
    """Send notification to all channels tracking this player by Account ID"""
    if account_id not in player_states:
        return
    
    channels = player_states[account_id]['tracking_channels']
    for channel_id in channels.copy():  # Use copy to avoid modification during iteration
        try:
            channel = bot.get_channel(channel_id)
            if channel:
                await channel.send(content=content, embed=embed)
            else:
                # Channel no longer exists, remove it
                channels.remove(channel_id)
        except Exception as e:
            logger.error(f"Failed to send notification to channel {channel_id}: {e}")
            # Remove problematic channel
            if channel_id in channels:
                channels.remove(channel_id)

def is_player_in_ranked_match(player_data: Dict[str, Any], account_id: str) -> bool:
    """Check if player is currently in a ranked match based on Season 15 stats changes"""
    if not player_data or account_id not in player_states:
        return False
    
    # Get current Season 15 ranked stats
    stats = player_data.get('stats', {})
    seasonal_stats = stats.get('seasonal_stats', [])
    
    current_s15_data = None
    for season in seasonal_stats:
        if season.get('season') == 15:
            current_s15_data = season
            break
    
    if not current_s15_data:
        return False
    
    current_ranked = current_s15_data.get('ranked', {})
    current_kills = current_ranked.get('k', 0)
    current_deaths = current_ranked.get('d', 0)
    current_assists = current_ranked.get('a', 0)
    
    state = player_states[account_id]
    baseline_stats = state.get('baseline_stats', {})
    
    if not baseline_stats:
        return False
    
    baseline_kills = baseline_stats.get('kills', 0)
    baseline_deaths = baseline_stats.get('deaths', 0)
    baseline_assists = baseline_stats.get('assists', 0)
    
    # Player is in match if any Season 15 ranked stat increased from baseline
    return (current_kills > baseline_kills or 
            current_deaths > baseline_deaths or 
            current_assists > baseline_assists)

async def send_new_match_cycle(account_id: str, player_data: Dict[str, Any]):
    """Send full message cycle (1, 2, 3) when player enters a new ranked match"""
    if account_id not in player_states:
        return
    
    state = player_states[account_id]
    current_username = player_data.get('basicInfo', {}).get('name', 'Unknown')
    
    # Extract all player info for message 1 (player stats with pink embed)
    basic_info = player_data.get('basicInfo', {})
    level_data = basic_info.get('playerLevel', 'N/A')
    if isinstance(level_data, dict):
        level = level_data.get('level', 'N/A')
    else:
        level = level_data
    
    # Get ban status
    ban_data = player_data.get('ban')
    ban_status = format_ban_status(ban_data)
    
    # Extract stats
    stats = player_data.get('stats', {})
    seasonal_stats = stats.get('seasonal_stats', [])
    
    # Calculate total casual stats
    total_kills = total_deaths = total_assists = 0
    for season in seasonal_stats:
        casual_data = season.get('casual', {})
        total_kills += casual_data.get('k', 0)
        total_deaths += casual_data.get('d', 0) 
        total_assists += casual_data.get('a', 0)
    
    total_kd = round(total_kills / total_deaths, 2) if total_deaths > 0 else total_kills
    
    # Current ranked stats
    ranked_stats = stats.get('ranked', {})
    current_mmr = ranked_stats.get('mmr', 0)
    
    # Season 15 ranked stats
    season_15_data = None
    for season in seasonal_stats:
        if season.get('season') == 15:
            season_15_data = season
            break
    
    if season_15_data:
        ranked_s15 = season_15_data.get('ranked', {})
        s15_kills = ranked_s15.get('k', 0)
        s15_deaths = ranked_s15.get('d', 0)
        s15_assists = ranked_s15.get('a', 0)
        s15_wins = ranked_s15.get('w', 0)
        s15_losses = ranked_s15.get('l', 0)
        s15_kd = round(s15_kills / s15_deaths, 2) if s15_deaths > 0 else float(s15_kills)
    else:
        s15_kills = s15_deaths = s15_assists = s15_wins = s15_losses = 0
        s15_kd = 0.0
    
    # Get account ID and clan info  
    account_id_display = basic_info.get('userID', 'N/A')
    clan_info = player_data.get('clan', {}).get('basicInfo', {})
    clan_tag = clan_info.get('tag', 'N/A')
    clan_name = clan_info.get('name', '')
    
    # Format clan display
    if clan_tag != 'N/A' and clan_name:
        clan_display = f"[{clan_tag}] - {clan_name}"
    elif clan_tag != 'N/A':
        clan_display = clan_tag
    else:
        clan_display = 'N/A'
    
    # MESSAGE 1: Player stats with pink embed
    stats_embed = discord.Embed(
        title=f"🦧 **{current_username} — Season 15**",
        color=discord.Color.magenta()
    )
    
    player_info_text = f"🆔 **Account ID:** {account_id_display}\n🏷️ **Clan:** {clan_display}\n📋 **Ban Status:** {ban_status}"
    stats_embed.add_field(name="", value=player_info_text, inline=False)
    
    elo_level_text = f"🏅 **ELO:** {current_mmr:,}\n📊 **Level:** {level}"
    stats_embed.add_field(name="", value=elo_level_text, inline=False)
    
    casual_stats_text = f"• **Kills:** {total_kills:,}\n• **Deaths:** {total_deaths:,}\n• **Assists:** {total_assists:,}\n• **K/D Ratio:** {total_kd}"
    stats_embed.add_field(name="⚔️ **Casual Stats**", value=casual_stats_text, inline=False)
    
    ranked_stats_text = f"• **Kills:** {s15_kills:,}\n• **Deaths:** {s15_deaths:,}\n• **Assists:** {s15_assists:,}\n• **Wins:** {s15_wins}\n• **Losses:** {s15_losses}\n• **K/D Ratio:** {s15_kd:.2f}"
    stats_embed.add_field(name="🏆 **Ranked Stats (S15)**", value=ranked_stats_text, inline=False)
    
    # MESSAGE 2: Tracking confirmation
    tracking_embed = discord.Embed(
        title="🟢 Now Tracking",
        description=f"**{current_username}** (ID: {account_id_display}) is now being monitored for updates",
        color=0x00FF00
    )
    tracking_embed.add_field(
        name="Monitoring Features:",
        value="• 🏆 Ranked match notifications (KDA, MMR changes)\n• ⚠️ Ban status alerts (reason, duration) - tracked by Account ID\n• 📝 Username change notifications - tracked by Account ID\n• 📊 Real-time stat updates",
        inline=False
    )
    tracking_embed.add_field(
        name="Stop Tracking",
        value=f"Use `/unsnipe {current_username}` to stop tracking.",
        inline=False
    )
    
    # Send messages 1 and 2 to all tracking channels
    channels = state['tracking_channels']
    for channel_id in channels:
        try:
            channel = bot.get_channel(channel_id)
            if channel:
                await channel.send(embed=stats_embed)
                await channel.send(embed=tracking_embed)
        except Exception as e:
            logger.error(f"Failed to send new match cycle messages to channel {channel_id}: {e}")
    
    # Store baseline stats from message 1 for change tracking
    if season_15_data:
        ranked_s15 = season_15_data.get('ranked', {})
        state['baseline_stats'] = {
            'kills': ranked_s15.get('k', 0),
            'deaths': ranked_s15.get('d', 0),
            'assists': ranked_s15.get('a', 0),
            'wins': ranked_s15.get('w', 0),
            'losses': ranked_s15.get('l', 0),
            'mmr': current_mmr
        }
    else:
        state['baseline_stats'] = {'kills': 0, 'deaths': 0, 'assists': 0, 'wins': 0, 'losses': 0, 'mmr': current_mmr}
    
    # Store current ban status and username for change detection
    state['last_ban_status'] = ban_data
    state['last_username'] = current_username
    
    # Player is not in match initially 
    state['in_ranked_match'] = False
    
    # MESSAGE 3: Send initial "not in ranked" status
    await send_initial_match_status(account_id, player_data)

async def send_initial_match_status(account_id: str, player_data: Dict[str, Any]):
    """Send initial message 3 showing player is not in ranked match yet"""
    if account_id not in player_states:
        return
    
    state = player_states[account_id]
    current_username = player_data.get('basicInfo', {}).get('name', 'Unknown')
    
    # Create "not in match" embed
    embed = discord.Embed(
        title="ℹ️ **Match Status**",
        description=f"**{current_username}** is not currently in a ranked match",
        color=discord.Color.blue()
    )
    embed.add_field(name="**Status**", value="⚪ **Not in Match**", inline=True)
    embed.add_field(name="**Monitoring**", value="Waiting for ranked match to begin...", inline=True)
    
    # Send to all tracking channels and store message references
    channels = state['tracking_channels']
    active_messages = {}
    
    for channel_id in channels:
        try:
            channel = bot.get_channel(channel_id)
            if channel:
                sent_message = await channel.send(embed=embed)
                active_messages[channel_id] = sent_message
        except Exception as e:
            logger.error(f"Failed to send initial match status to channel {channel_id}: {e}")
    
    # Store message references for future editing
    state['active_match_messages'] = active_messages

async def send_ranked_status_message(account_id: str, player_data: Dict[str, Any]):
    """Send ranked status message (in match or not in match)"""
    if account_id not in player_states:
        return
    
    state = player_states[account_id]
    current_username = player_data.get('basicInfo', {}).get('name', 'Unknown')
    is_in_match = is_player_in_ranked_match(player_data, account_id)
    
    if is_in_match and not state.get('in_ranked_match', False):
        # Player just entered a ranked match
        await update_match_status_live(account_id, player_data, match_start=True)
        state['in_ranked_match'] = True
        state['match_start_time'] = datetime.now()
        
    elif is_in_match and state.get('in_ranked_match', False):
        # Player is still in match, update live stats
        await update_match_status_live(account_id, player_data, match_start=False)
        
    elif not is_in_match and state.get('in_ranked_match', False):
        # Player finished match
        await update_match_status_complete(account_id, player_data)
        state['in_ranked_match'] = False
        # Update baseline stats for next match
        await update_baseline_stats(account_id, player_data)

async def update_match_status_live(account_id: str, player_data: Dict[str, Any], match_start: bool = False):
    """Update the live match status message"""
    if account_id not in player_states:
        return
    
    state = player_states[account_id]
    current_username = player_data.get('basicInfo', {}).get('name', 'Unknown')
    
    # Get current Season 15 ranked stats
    stats = player_data.get('stats', {})
    seasonal_stats = stats.get('seasonal_stats', [])
    
    current_s15_data = None
    for season in seasonal_stats:
        if season.get('season') == 15:
            current_s15_data = season
            break
    
    if not current_s15_data:
        return
    
    current_ranked = current_s15_data.get('ranked', {})
    current_kills = current_ranked.get('k', 0)
    current_deaths = current_ranked.get('d', 0)
    current_assists = current_ranked.get('a', 0)
    current_wins = current_ranked.get('w', 0)
    current_losses = current_ranked.get('l', 0)
    
    baseline_stats = state.get('baseline_stats', {})
    baseline_kills = baseline_stats.get('kills', 0)
    baseline_deaths = baseline_stats.get('deaths', 0)
    baseline_assists = baseline_stats.get('assists', 0)
    baseline_wins = baseline_stats.get('wins', 0)
    baseline_losses = baseline_stats.get('losses', 0)
    
    # Calculate incremental stats (no "+" symbols)
    match_kills = current_kills - baseline_kills
    match_deaths = current_deaths - baseline_deaths
    match_assists = current_assists - baseline_assists
    match_wins = current_wins - baseline_wins
    match_losses = current_losses - baseline_losses
    
    # Calculate K/D ratio to 2 decimal places
    kd_ratio = round(match_kills / match_deaths, 2) if match_deaths > 0 else float(match_kills)
    
    # Calculate win rate
    total_match_games = match_wins + match_losses
    win_rate = round((match_wins / total_match_games) * 100, 1) if total_match_games > 0 else 0.0
    
    # Calculate match duration if available
    match_duration = ""
    if 'match_start_time' in state:
        duration = datetime.now() - state['match_start_time']
        minutes = int(duration.total_seconds() // 60)
        seconds = int(duration.total_seconds() % 60)
        match_duration = f" (Duration: {minutes}m {seconds}s)"
    
    # Create live match embed
    embed = discord.Embed(
        title="🔥 **Live Ranked Match**",
        description=f"**{current_username}** is currently in a ranked match{match_duration}",
        color=discord.Color.orange()
    )
    
    kda_text = f"• **Kills:** {match_kills}\n• **Deaths:** {match_deaths}\n• **Assists:** {match_assists}\n• **K/D Ratio:** {kd_ratio:.2f}"
    embed.add_field(name="📊 **Match KDA**", value=kda_text, inline=True)
    
    match_record_text = f"• **Wins:** {match_wins}\n• **Losses:** {match_losses}\n• **Win Rate:** {win_rate:.1f}%"
    embed.add_field(name="🏆 **Match Record**", value=match_record_text, inline=True)
    
    embed.add_field(name="**Status**", value="🟠 **Live Match**", inline=False)
    
    # Edit existing messages
    active_messages = state.get('active_match_messages', {})
    for channel_id, message in active_messages.items():
        try:
            await message.edit(embed=embed)
        except Exception as e:
            logger.error(f"Failed to edit match status message in channel {channel_id}: {e}")

async def update_match_status_complete(account_id: str, player_data: Dict[str, Any]):
    """Update message when match is complete"""
    if account_id not in player_states:
        return
    
    state = player_states[account_id]
    current_username = player_data.get('basicInfo', {}).get('name', 'Unknown')
    
    # Get current MMR
    stats = player_data.get('stats', {})
    ranked_stats = stats.get('ranked', {})
    current_mmr = ranked_stats.get('mmr', 0)
    
    baseline_stats = state.get('baseline_stats', {})
    baseline_mmr = baseline_stats.get('mmr', 0)
    mmr_change = current_mmr - baseline_mmr
    
    # Calculate match duration
    match_duration = ""
    if 'match_start_time' in state:
        duration = datetime.now() - state['match_start_time']
        minutes = int(duration.total_seconds() // 60)
        seconds = int(duration.total_seconds() % 60)
        match_duration = f" (Duration: {minutes}m {seconds}s)"
    
    # Get final match stats
    seasonal_stats = stats.get('seasonal_stats', [])
    current_s15_data = None
    for season in seasonal_stats:
        if season.get('season') == 15:
            current_s15_data = season
            break
    
    if current_s15_data:
        current_ranked = current_s15_data.get('ranked', {})
        current_kills = current_ranked.get('k', 0)
        current_deaths = current_ranked.get('d', 0)
        current_assists = current_ranked.get('a', 0)
        current_wins = current_ranked.get('w', 0)
        current_losses = current_ranked.get('l', 0)
        
        match_kills = current_kills - baseline_stats.get('kills', 0)
        match_deaths = current_deaths - baseline_stats.get('deaths', 0)
        match_assists = current_assists - baseline_stats.get('assists', 0)
        match_wins = current_wins - baseline_stats.get('wins', 0)
        match_losses = current_losses - baseline_stats.get('losses', 0)
        
        kd_ratio = round(match_kills / match_deaths, 2) if match_deaths > 0 else float(match_kills)
        
        total_match_games = match_wins + match_losses
        win_rate = round((match_wins / total_match_games) * 100, 1) if total_match_games > 0 else 0.0
    else:
        match_kills = match_deaths = match_assists = match_wins = match_losses = 0
        kd_ratio = 0.0
        win_rate = 0.0
    
    # Create match complete embed
    embed = discord.Embed(
        title="✅ **Match Complete**",
        description=f"**{current_username}** finished their ranked match{match_duration}",
        color=discord.Color.green()
    )
    
    kda_text = f"• **Kills:** {match_kills}\n• **Deaths:** {match_deaths}\n• **Assists:** {match_assists}\n• **K/D Ratio:** {kd_ratio:.2f}"
    embed.add_field(name="📊 **Final KDA**", value=kda_text, inline=True)
    
    match_record_text = f"• **Wins:** {match_wins}\n• **Losses:** {match_losses}\n• **Win Rate:** {win_rate:.1f}%"
    embed.add_field(name="🏆 **Final Record**", value=match_record_text, inline=True)
    
    mmr_change_text = f"**{current_mmr:,}** ({mmr_change:+})"
    embed.add_field(name="🏅 **MMR**", value=mmr_change_text, inline=False)
    
    # Edit existing messages
    active_messages = state.get('active_match_messages', {})
    for channel_id, message in active_messages.items():
        try:
            await message.edit(embed=embed)
        except Exception as e:
            logger.error(f"Failed to edit match complete message in channel {channel_id}: {e}")

async def update_baseline_stats(account_id: str, player_data: Dict[str, Any]):
    """Update baseline stats after match completion"""
    if account_id not in player_states:
        return
    
    state = player_states[account_id]
    stats = player_data.get('stats', {})
    seasonal_stats = stats.get('seasonal_stats', [])
    ranked_stats = stats.get('ranked', {})
    current_mmr = ranked_stats.get('mmr', 0)
    
    # Update baseline with current stats
    season_15_data = None
    for season in seasonal_stats:
        if season.get('season') == 15:
            season_15_data = season
            break
    
    if season_15_data:
        ranked_s15 = season_15_data.get('ranked', {})
        state['baseline_stats'] = {
            'kills': ranked_s15.get('k', 0),
            'deaths': ranked_s15.get('d', 0),
            'assists': ranked_s15.get('a', 0),
            'wins': ranked_s15.get('w', 0),
            'losses': ranked_s15.get('l', 0),
            'mmr': current_mmr
        }

async def check_player_changes(account_id: str, player_data: Dict[str, Any]):
    """Check for ban status and username changes"""
    if account_id not in player_states:
        return
    
    state = player_states[account_id]
    current_username = player_data.get('basicInfo', {}).get('name', 'Unknown')
    current_ban_data = player_data.get('ban')
    
    # Check for username change
    last_username = state.get('last_username', '')
    if last_username and last_username != current_username:
        await send_username_change_notification(account_id, last_username, current_username)
        state['last_username'] = current_username
    
    # Check for ban status change
    last_ban_data = state.get('last_ban_status')
    current_ban_status = format_ban_status(current_ban_data)
    last_ban_status = format_ban_status(last_ban_data)
    
    if last_ban_status != current_ban_status:
        await send_ban_change_notification(account_id, current_username, current_ban_data, last_ban_data)
        state['last_ban_status'] = current_ban_data
        
        # Check if permanently banned - auto-stop tracking
        if current_ban_data and current_ban_data.get('type') == 'Permanent':
            await send_permanent_ban_notification(account_id, current_username, current_ban_data)
            await auto_remove_permanently_banned_player(account_id, current_username)

async def send_username_change_notification(account_id: str, old_username: str, new_username: str):
    """Send notification when username changes"""
    embed = discord.Embed(
        title="📝 **Username Change Detected**",
        description=f"Player has changed their username",
        color=discord.Color.blue()
    )
    
    embed.add_field(name="🆔 **Account ID**", value=account_id, inline=False)
    embed.add_field(name="**Old Username**", value=old_username, inline=True)
    embed.add_field(name="**New Username**", value=new_username, inline=True)
    embed.add_field(name="**Tracking Status**", value="✅ **Still Tracking** (by Account ID)", inline=False)
    
    await send_notification_to_trackers(account_id, "", embed)

async def send_ban_change_notification(account_id: str, username: str, current_ban_data: Dict[str, Any], last_ban_data: Dict[str, Any]):
    """Send notification when ban status changes"""
    current_ban_status = format_ban_status(current_ban_data)
    last_ban_status = format_ban_status(last_ban_data)
    
    if current_ban_data and not last_ban_data:
        # Player got banned
        embed = discord.Embed(
            title="⚠️ **Player Banned**",
            description=f"**{username}** has been banned",
            color=discord.Color.red()
        )
        
        ban_reason = current_ban_data.get('reason', 'Unknown')
        embed.add_field(name="🆔 **Account ID**", value=account_id, inline=False)
        embed.add_field(name="**Ban Type**", value=current_ban_status, inline=True)
        embed.add_field(name="**Reason**", value=ban_reason, inline=True)
        
    elif not current_ban_data and last_ban_data:
        # Player got unbanned
        embed = discord.Embed(
            title="✅ **Player Unbanned**",
            description=f"**{username}** has been unbanned",
            color=discord.Color.green()
        )
        
        embed.add_field(name="🆔 **Account ID**", value=account_id, inline=False)
        embed.add_field(name="**Previous Ban**", value=last_ban_status, inline=True)
        embed.add_field(name="**Current Status**", value="✅ **Not Banned**", inline=True)
        
    else:
        # Ban status changed (e.g., temporary to permanent)
        embed = discord.Embed(
            title="🔄 **Ban Status Changed**",
            description=f"**{username}**'s ban status has changed",
            color=discord.Color.orange()
        )
        
        embed.add_field(name="🆔 **Account ID**", value=account_id, inline=False)
        embed.add_field(name="**Previous Status**", value=last_ban_status, inline=True)
        embed.add_field(name="**Current Status**", value=current_ban_status, inline=True)
    
    await send_notification_to_trackers(account_id, "", embed)

async def send_permanent_ban_notification(account_id: str, username: str, ban_data: Dict[str, Any]):
    """Send notification with ASCII art when player is permanently banned"""
    ban_reason = ban_data.get('reason', 'Unknown')
    
    ascii_art = """
